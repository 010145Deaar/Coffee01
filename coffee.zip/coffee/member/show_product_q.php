<?php  
$q = isset($_GET['q']) ? $_GET['q'] : ''; // ตรวจสอบว่ามีการส่งค่าคำค้นหามาหรือไม่
$type_id = isset($_GET['type_id']) ? $_GET['type_id'] : ''; // รับค่าประเภทสินค้าที่เลือก
include("../condb.php");
if($_SESSION['m_level']!='member'){
	Header("Location: index.php");
}

// สร้าง SQL query สำหรับดึงข้อมูลสินค้า
$sql = "SELECT p.p_id, p.p_name, p.p_img, p.p_price, t.type_id, t.type_name 
        FROM tbl_product AS p
        INNER JOIN tbl_type AS t ON p.type_id = t.type_id";

// ถ้ามีการค้นหาสินค้าจากคำค้น ให้กรองตามชื่อสินค้า
if (!empty($q)) {
    $sql .= " WHERE p.p_name LIKE '%$q%'";
}

// ถ้ามีการเลือกประเภทสินค้า ให้กรองสินค้าเฉพาะประเภทที่เลือก
if (!empty($type_id)) {
    $sql .= " AND p.type_id = '$type_id'";
}

$sql .= " ORDER BY p.p_id DESC";  // เรียงลำดับข้อมูลล่าสุดขึ้นก่อน

$result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error($con));
?>

<div class="container">
    <h2>สินค้าทั้งหมด</h2> <!-- หรือชื่อหมวดหมู่ที่เลือก -->
    <div class="row">
        <?php if (mysqli_num_rows($result) > 0) { ?>
            <?php while ($row_prd = mysqli_fetch_array($result)) { ?>
                <div class="col-lg-3 col-md-4 col-sm-6 col-12 mb-4 d-flex justify-content-center">
                    <div class="card border-light" style="width: 100%; max-width: 300px;">
                        <a href="prd.php?id=<?php echo $row_prd['p_id']; ?>" class="text-center">
                            <img src="../p_img/<?php echo $row_prd['p_img']; ?>" class="card-img-top img-fluid" alt="<?php echo $row_prd['p_name']; ?>" style="height: auto; max-height: 200px; object-fit: cover;">
                        </a>
                        <div class="card-body text-center">
                            <a href="prd.php?id=<?php echo $row_prd['p_id']; ?>"><b><?php echo $row_prd["p_name"]; ?></b></a>
                            <p class="mb-2">ราคา <span class="text-danger"><?php echo $row_prd["p_price"]; ?></span> บาท</p>
                            <a href="prd.php?id=<?php echo $row_prd['p_id']; ?>" class="btn btn-info btn-sm text-white">รายละเอียด</a>
                        </div>
                    </div>
                </div>
            <?php } ?>
        <?php } else { ?>
            <p>ไม่พบสินค้าที่ตรงกับคำค้นหา</p>
        <?php } ?>
    </div>
</div>

<?php 
// ปิดการเชื่อมต่อฐานข้อมูล
mysqli_close($con);
?>
