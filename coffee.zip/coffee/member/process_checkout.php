<?php
session_start();
include("../condb.php");
include('banner.php');
include('navbar.php');

// ตรวจสอบการเข้าสู่ระบบ
if (!isset($_SESSION["member_id"])) {
    echo "<p>กรุณาเข้าสู่ระบบก่อนดำเนินการสั่งซื้อ</p>";
    echo "<a href='login.php' class='btn btn-warning'>เข้าสู่ระบบ</a>";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $member_id = $_SESSION["member_id"];
    $m_name = mysqli_real_escape_string($con, $_POST["m_name"]);
    $m_tel = mysqli_real_escape_string($con, $_POST["m_tel"]);
    $delivery_address = mysqli_real_escape_string($con, $_POST["delivery_address"]);
    $pay = mysqli_real_escape_string($con, $_POST["pay"]);
    $pay_img = ''; // กำหนดค่าเริ่มต้นให้เป็นค่าว่าง

    // ตรวจสอบว่ามีการอัพโหลดไฟล์หรือไม่
    if ($pay === 'โอนเงิน' && isset($_FILES['pay_img']) && $_FILES['pay_img']['error'] == 0) {
        // ใช้ชื่อเดิมของไฟล์จากฟอร์ม
        $pay_img = $_FILES['pay_img']['name'];  // ชื่อไฟล์เดิมจากการอัพโหลด

        // เก็บไฟล์ในโฟลเดอร์ uploads โดยไม่ย้าย (แค่เก็บชื่อไฟล์ในฐานข้อมูล)
        // ถ้าต้องการให้ไฟล์เก็บในโฟลเดอร์ uploads โดยไม่ทำการย้ายไฟล์
        // สามารถเพิ่มโค้ดนี้ถ้าต้องการ:
        move_uploaded_file($_FILES['pay_img']['tmp_name'], '../uploads/' . $pay_img);
    }

    // คำนวณราคารวม
    $total_amount = 0;
    if (isset($_SESSION["cart"]) && !empty($_SESSION["cart"])) {
        foreach ($_SESSION["cart"] as $item) {
            $total_amount += $item["p_allprice"];
        }
    } else {
        echo "<p>ตะกร้าสินค้าว่างเปล่า</p>";
        echo "<a href='index.php' class='btn btn-warning'>เลือกสินค้าต่อ</a>";
        exit();
    }

    // บันทึกข้อมูลลงในตาราง orders
    $sql = "INSERT INTO orders (member_id, total_amount, status, order_date, delivery_address, phone_number, pay, pay_img) 
            VALUES (?, ?, 'รอดำเนินการ', NOW(), ?, ?, ?, ?)";
    $stmt = mysqli_prepare($con, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'idssss', $member_id, $total_amount, $delivery_address, $m_tel, $pay, $pay_img);

        if (mysqli_stmt_execute($stmt)) {
            echo "คำสั่งซื้อได้รับการบันทึกแล้ว!<br>";
            $order_id = mysqli_insert_id($con);
            echo "Order ID: " . $order_id;
        } else {
            echo "Error executing statement: " . mysqli_error($con);
        }
    } else {
        echo "Error preparing statement: " . mysqli_error($con);
    }

    foreach ($_SESSION["cart"] as $item) {
        // จัดการค่า topping_id เป็น string ถ้าเป็น array
        $topping_ids = is_array($item["topping_id"]) ? implode(",", $item["topping_id"]) : $item["topping_id"];
    
        // ตรวจสอบว่าราคา (p_price) มีค่าหรือไม่
        $item_price = isset($item["p_price"]) ? $item["p_price"] : 0.00;
    
        $sql = "INSERT INTO order_details (order_id, p_id, quantity, price, topping_id, mix_id, sugar_id) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($con, $sql);
    
        // ตรวจสอบการสร้าง statement
        if (!$stmt) {
            echo "Error preparing statement: " . mysqli_error($con);
            exit();
        }
    
        mysqli_stmt_bind_param($stmt, 'iiidiii', 
            $order_id, 
            $item["p_id"], 
            $item["quantity"], 
            $item_price, // ใช้ $item_price ที่ตรวจสอบแล้ว
            $topping_ids, 
            $item["mix_id"], 
            $item["sugar_id"]
        );
    
        // ตรวจสอบการ execute
        if (!mysqli_stmt_execute($stmt)) {
            echo "Error executing statement: " . mysqli_error($con);
            exit();
        }
    }    
    
    // ล้างตะกร้าสินค้า
    unset($_SESSION["cart"]);

    echo "<div class='alert alert-success' role='alert'>คำสั่งซื้อของคุณได้รับการบันทึกเรียบร้อยแล้ว!</div>";
    echo "<a href='index.php' class='btn btn-primary'>กลับไปหน้าแรก</a>";
} else {
    echo "<p>เกิดข้อผิดพลาดในการบันทึกคำสั่งซื้อ กรุณาลองใหม่อีกครั้ง</p>";
}
?>
