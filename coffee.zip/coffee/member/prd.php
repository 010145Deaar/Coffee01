<?php
include('h.php');
include("../condb.php");

if (!isset($_GET["id"])) {
    die("ID ไม่ถูกต้อง");
}

if (isset($_GET["id"]) && is_numeric($_GET["id"])) {
  $p_id = $_GET["id"];
  $sql = "SELECT * FROM tbl_product WHERE p_id = $p_id";
  $result = mysqli_query($con, $sql);
  if (mysqli_num_rows($result) == 0) {
      die("ไม่พบสินค้าหมายเลขนี้ในระบบ");
  }
  $row = mysqli_fetch_assoc($result);
} 

$sql = "SELECT p.*, t.type_name 
        FROM tbl_product AS p 
        INNER JOIN tbl_type AS t ON p.type_id = t.type_id 
        WHERE p.p_id = $p_id";

$result = mysqli_query($con, $sql) or die("Error in query: $sql " . mysqli_error());
if (mysqli_num_rows($result) == 0) {
    die("ไม่พบสินค้าหมายเลขนี้ในระบบ");
}
$row = mysqli_fetch_array($result);
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="mystyle.css">
    <title>รายละเอียดสินค้า</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <?php
    include('banner.php');  
    include('navbar.php');    
    ?>
<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-md-10 col-12">
            <div class="container product-details" style="margin-top: 50px;">
                <div class="row">
                    <div class="col-md-6 col-12 text-center">
                        <div class="zoom">
                            <?php echo "<img src='../p_img/".$row['p_img']."' class='img-fluid'>"; ?>
                        </div>
                    </div>
                    <div class="col-md-6 col-12">
                        <h4 class="mb-3"><b><?php echo $row["p_name"]; ?></b></h4>
                        <p><?php echo $row["p_detail"]; ?></p>
                        <p>
                            ประเภท: <?php echo $row["type_name"]; ?>
                            <br>
                            ราคา: <span class="price-display"><?php echo $row["p_price"]; ?> บาท</span>
                        </p>
                            <input type="hidden" name="p_price" value="<?php echo $row['p_price']; ?>">

                                <!-- ฟอร์มสำหรับส่งข้อมูลไปยัง cart.php -->
                            <form action="cart.php" method="POST">
                                <!-- ส่งค่ารหัสสินค้า -->
                                <input type="hidden" name="p_id" value="<?php echo $row['p_id']; ?>">
                                <!-- ส่งค่าราคาสินค้า -->
                                <input type="hidden" name="p_price" value="<?php echo $row['p_price']; ?>">
                                <div class="form-group">
                                    <!-- ส่งค่าความหวาน -->
                                <select name="sugar_id" id="sugar_id" required onchange="calculateTotalPrice()">
                                    <option value="">เลือกระดับความหวาน</option>
                                    <?php
                                    // ดึงข้อมูลระดับความหวานจากฐานข้อมูล
                                    $sql = "SELECT sugar_id, s_name FROM tbl_sugar ORDER BY sugar_id ASC";
                                    $result_sugar = mysqli_query($con, $sql) or die("Error in query: $sql " . mysqli_error($con));
                                    while ($sugar = mysqli_fetch_assoc($result_sugar)) {
                                        // เพิ่ม data-price เพื่อรองรับการคำนวณราคารวม
                                        echo '<option value="' . $sugar['sugar_id'] . '" data-price="0">' . $sugar['s_name'] . '</option>';
                                    }
                                    ?>
                                </select>
                                <!-- เลือกท็อปปิ้ง -->
                                <div class="form-group">
                                    <label for="topping_id">เลือกท็อปปิ้ง:</label>
                                    <select name="topping_id" id="topping_id" class="form-control" onchange="calculateTotalPrice()">
                                        <option value="">เลือกท็อปปิ้ง</option>
                                        <?php
                                        $sql = "SELECT topping_id, t_topping, t_price FROM tbl_topping ORDER BY topping_id ASC";
                                        $result_topping = mysqli_query($con, $sql);
                                        while ($topping = mysqli_fetch_assoc($result_topping)) {
                                            echo '<option value="' . $topping['topping_id'] . '" data-price="' . $topping['t_price'] . '">'
                                                . $topping['t_topping'] . ' (+' . $topping['t_price'] . ' บาท)</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                                <!-- เลือกการปั่น -->
                                <div class="form-group">
                                    <label for="mix_id">เลือกการปั่น:</label>
                                    <select name="mix_id" id="mix_id" class="form-control" onchange="calculateTotalPrice()" required>
                                        <option value="">เลือกการปั่น</option>
                                        <?php
                                        $sql = "SELECT mix_id, m_mix, m_price FROM tbl_mix ORDER BY mix_id ASC";
                                        $result_mix = mysqli_query($con, $sql);

                                        while ($mix = mysqli_fetch_assoc($result_mix)) {
                                            // เงื่อนไข: หาก type_id = 4 ให้แสดงเฉพาะ mix_id = 13
                                            if ($row['type_id'] == 4 && $mix['mix_id'] != 13) {
                                                continue; // ข้ามตัวเลือกอื่นๆ
                                            }

                                            // เงื่อนไข: หาก type_id != 4 ให้ข้าม mix_id = 13
                                            if ($row['type_id'] != 4 && $mix['mix_id'] == 13) {
                                                continue; // ข้าม mix_id = 13
                                            }

                                            // เพิ่มตัวเลือกใน Dropdown
                                            echo '<option value="' . $mix['mix_id'] . '" data-price="' . $mix['m_price'] . '">'
                                                . $mix['m_mix'] . ' (+' . $mix['m_price'] . ' บาท)</option>';
                                        }
                                        ?>
                                    </select>
                                </div>
                                <!-- ราคารวม -->
                                <div class="form-group">
                                    <label for="p_allprice">ราคารวม:</label>
                                    <input type="number" name="p_allprice" id="p_allprice" class="form-control" readonly>
                                </div>
                                 <!-- ปุ่มเพิ่มสินค้าไปยังตะกร้า -->
                                <button type="submit" class="btn btn-primary">เพิ่มลงตะกร้า</button>
                                </form>
                            <head>
                            <script defer>
                                function calculateTotalPrice() {
                                let basePrice = parseFloat(<?php echo $row["p_price"]; ?>);
                                let toppingPrice = parseFloat($("#topping_id option:selected").data("price") || 0);
                                let mixPrice = parseFloat($("#mix_id option:selected").data("price") || 0);
                                let sugarPrice = parseFloat($("#sugar_id option:selected").data("price") || 0);

                                // คำนวณราคารวม
                                let totalPrice = basePrice + toppingPrice + mixPrice + sugarPrice;
                                $("#p_allprice").val(totalPrice.toFixed(2));
                            }
                            $(document).ready(function () {
                                $("#topping_id, #mix_id, #sugar_id").on("change", calculateTotalPrice);
                            });
                            </script>
                        </head>
 
                            </script>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>