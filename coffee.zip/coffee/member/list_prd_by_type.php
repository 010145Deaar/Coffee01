<?php
include("../condb.php");
if($_SESSION['m_level']!='member'){
	Header("Location: index.php");
}

// ดึงข้อมูลประเภทสินค้าจาก tbl_type
$query_typeprd = "SELECT * FROM tbl_type ORDER BY type_id ASC";
$typeprd = mysqli_query($con, $query_typeprd) or die("Error in query: $query_typeprd " . mysqli_error($con));
?>

<div class="container">
    <h2>เลือกประเภทสินค้า</h2>
    <div class="row">
        <?php while ($row_typeprd = mysqli_fetch_assoc($typeprd)) { ?>
            <div class="col-md-3">
                <a href="index.php?type_id=<?php echo $row_typeprd['type_id']; ?>" class="btn btn-warning btn-block">
                    <?php echo $row_typeprd['type_name']; ?>
                </a>
            </div>
        <?php } ?>
    </div>
</div>

<?php 
// ปิดการเชื่อมต่อฐานข้อมูล
mysqli_close($con);
?>
