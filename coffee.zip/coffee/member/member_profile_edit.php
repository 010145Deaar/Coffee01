<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แก้ไขข้อมูลส่วนตัว</title>
    <!-- CSS Libraries -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* ปรับแต่งภาพ preview */
        #preview {
            max-width: 100%;
            height: auto;
            border: 2px dashed #ddd;
            padding: 5px;
            margin-top: 10px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">แก้ไขข้อมูลส่วนตัว</h2>
        <form action="member_profile_edit_db.php" method="post" enctype="multipart/form-data">
            <div class="form-row">
                <!-- Username -->
                <div class="form-group col-md-6">
                    <label for="m_user">Username:</label>
                    <input type="text" name="m_user" class="form-control" pattern="^[a-zA-Z0-9]+$" 
                           title="ภาษาอังกฤษหรือตัวเลขเท่านั้น" required value="<?php echo $row['m_user']; ?>">
                </div>
                <!-- ชื่อ-นามสกุล -->
                <div class="form-group col-md-6">
                    <label for="m_name">ชื่อ-นามสกุล:</label>
                    <input type="text" name="m_name" class="form-control" required value="<?php echo $row['m_name']; ?>">
                </div>
            </div>
            
            <div class="form-row">
                <!-- เบอร์โทร -->
                <div class="form-group col-md-6">
                    <label for="m_tel">เบอร์โทร:</label>
                    <input type="text" name="m_tel" class="form-control" required value="<?php echo $row['m_tel']; ?>">
                </div>
                <!-- อีเมล -->
                <div class="form-group col-md-6">
                    <label for="m_email">อีเมล:</label>
                    <input type="email" name="m_email" class="form-control" required value="<?php echo $row['m_email']; ?>">
                </div>
            </div>
            
            <div class="form-group">
                <!-- ที่อยู่ -->
                <label for="m_address">ที่อยู่:</label>
                <input type="text" name="m_address" class="form-control" required value="<?php echo $row['m_address']; ?>">
            </div>
            
            <div class="form-group">
                <!-- รูปภาพ -->
                <label for="m_img">รูปภาพ:</label>
                <p>ภาพเก่า:</p>
                <img src="../m_img/<?php echo $row['m_img']; ?>" alt="ภาพเก่า" class="img-fluid mb-2" style="max-width: 200px;">
                <input type="file" name="m_img" class="form-control-file" accept="image/*" onchange="previewImage(this);">
                <img id="preview" alt="Preview">
            </div>
            
            <div class="form-row">
                <div class="form-group col-md-6">
                    <input type="hidden" name="m_img2" value="<?php echo $row['m_img']; ?>">
                    <input type="hidden" name="member_id" value="<?php echo $member_id; ?>">
                    <button type="submit" class="btn btn-success btn-block">บันทึก</button>
                </div>
                <div class="form-group col-md-6">
                    <a href="index.php" class="btn btn-danger btn-block">ยกเลิก</a>
                </div>
            </div>
        </form>
    </div>

    <!-- JS Libraries -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // ฟังก์ชันแสดงตัวอย่างภาพที่อัปโหลด
        function previewImage(input) {
            var preview = document.getElementById('preview');
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                };

                reader.readAsDataURL(input.files[0]);
            } else {
                preview.src = '';
                preview.style.display = 'none';
            }
        }
    </script>
</body>
</html>
