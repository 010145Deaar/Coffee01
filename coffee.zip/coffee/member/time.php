<?php 
session_start();
include('../condb.php'); // เชื่อมต่อฐานข้อมูล

// ตรวจสอบว่าเข้าสู่ระบบแล้วหรือยัง
if (!isset($_SESSION['member_id'])) {
    header("Location: login.php");
    exit();
}

$member_id = $_SESSION['member_id']; // รหัสสมาชิกที่ล็อกอิน

// การตั้งค่า group_concat_max_len เพื่อป้องกันข้อมูลถูกตัด
mysqli_query($con, "SET SESSION group_concat_max_len = 1000000");

// การตั้งค่าการแบ่งหน้า
$limit = 10; // จำนวนคำสั่งซื้อที่จะแสดงต่อหน้า
$page = max(1, intval($_GET['page'] ?? 1));
$offset = ($page - 1) * $limit;

// ดึงข้อมูลคำสั่งซื้อของสมาชิกพร้อมรายละเอียดสินค้า
$sql = "SELECT o.order_id, o.member_id, o.total_amount, o.status, o.order_date, o.delivery_address, 
        o.pay, o.pay_img, o.phone_number, 
        GROUP_CONCAT(
            CONCAT(
                p.p_name, ' x', od.quantity, 
                IF(t.t_topping IS NOT NULL, CONCAT(' (Topping: ', t.t_topping, ')'), ''), 
                IF(mx.m_mix IS NOT NULL, CONCAT(' (Mix: ', mx.m_mix, ')'), ''), 
                IF(s.s_name IS NOT NULL, CONCAT(' (Sugar: ', s.s_name, ')'), '')
            ) SEPARATOR '<br>' 
        ) AS p_id
        FROM orders o
        LEFT JOIN order_details od ON o.order_id = od.order_id
        LEFT JOIN tbl_product p ON od.p_id = p.p_id
        LEFT JOIN tbl_topping t ON od.topping_id = t.topping_id
        LEFT JOIN tbl_mix mx ON od.mix_id = mx.mix_id
        LEFT JOIN tbl_sugar s ON od.sugar_id = s.sugar_id
        WHERE o.member_id = ?
        GROUP BY o.order_id
        ORDER BY o.order_date DESC
        LIMIT ? OFFSET ?";

$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, 'iii', $member_id, $limit, $offset);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// คำนวณจำนวนหน้าทั้งหมด
$countQuery = "SELECT COUNT(*) AS total_orders FROM orders WHERE member_id = ?";
$countStmt = mysqli_prepare($con, $countQuery);
mysqli_stmt_bind_param($countStmt, 'i', $member_id);
mysqli_stmt_execute($countStmt);
$countResult = mysqli_stmt_get_result($countStmt);
$totalOrders = mysqli_fetch_assoc($countResult)['total_orders'];
$totalPages = ceil($totalOrders / $limit);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ประวัติการสั่งซื้อ</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<?php
    include('banner.php');  
    include('navbar.php');    
?>
<body>
<div class="container mt-5">
    <h2 class="text-center">ประวัติการสั่งซื้อ</h2>
    <div class="row">
        <?php
        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
        ?>
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h5>รหัสคำสั่งซื้อ: <?php echo $row['order_id']; ?></h5>
                </div>
                <div class="card-body">
                <p><strong>รายการสินค้า:</strong></p>
                    <?php
                    if ($row['p_id']) {
                        // แยกรายการสินค้าที่มีการคั่นด้วย <br>
                        $products = explode('<br>', $row['p_id']);
                        
                        // วนลูปแสดงสินค้าทีละรายการในบรรทัดใหม่
                        foreach ($products as $product) {
                            echo '<p>' . htmlspecialchars($product) . '</p>';
                        }
                    } else {
                        echo "<p>ไม่มีสินค้าที่ถูกเลือกในคำสั่งซื้อ</p>";
                    }
                    ?>
                    <p><strong>จำนวนเงินรวม:</strong> <?php echo number_format($row['total_amount'], 2); ?> บาท</p>
                    <p><strong>สถานะ:</strong> 
                        <?php
                        if ($row['status'] === 'จัดส่งสำเร็จ') {
                            echo '<span class="badge badge-success">จัดส่งสำเร็จ</span>';
                        } elseif ($row['status'] === 'รอการชำระเงิน') {
                            echo '<span class="badge badge-warning">รอการชำระเงิน</span>';
                        } else {
                            echo '<span class="badge badge-primary">' . $row['status'] . '</span>';
                        }
                        ?>
                    </p>
                    <p><strong>วันที่สั่งซื้อ:</strong> <?php echo date('Y-m-d H:i:s', strtotime($row['order_date'])); ?></p>
                    <p><strong>การจัดส่ง:</strong> <?php echo htmlspecialchars($row['delivery_address']); ?></p>
                    <p><strong>วิธีการชำระเงิน:</strong> <?php echo htmlspecialchars($row['pay']); ?></p>
                    <p><strong>หมายเลขโทรศัพท์:</strong> <?php echo htmlspecialchars($row['phone_number']); ?></p>
                    
                    <?php if ($row['pay_img']) { ?>
                    <p><strong>ภาพใบเสร็จ:</strong><br>
                        <img src="../uploads/<?php echo htmlspecialchars($row['pay_img']); ?>" alt="Pay Image" class="img-fluid" width="200">
                    </p>
                    <?php } ?>
                </div>
                <div class="card-footer text-right">
                    <form action="cart2.php" method="POST">
                    <input type="hidden" name="order_id" value="<?php echo $row['order_id']; ?>">
                    <input type="hidden" name="total_amount" value="<?php echo $row['total_amount']; ?>">

                    <?php
                    $order_id = $row['order_id']; 
                    $detailSql = "SELECT p_id, GROUP_CONCAT(topping_id) AS topping_id, mix_id, sugar_id FROM order_details WHERE order_id = ? GROUP BY p_id, mix_id, sugar_id";
                    $detailStmt = mysqli_prepare($con, $detailSql);
                    mysqli_stmt_bind_param($detailStmt, 'i', $order_id);
                    mysqli_stmt_execute($detailStmt);
                    $detailResult = mysqli_stmt_get_result($detailStmt);

                    while ($item = mysqli_fetch_assoc($detailResult)) {
                        echo '<input type="hidden" name="p_id[]" value="' . htmlspecialchars($item['p_id']) . '">';
                        echo '<input type="hidden" name="topping_id[]" value="' . htmlspecialchars($item['topping_id']) . '">';
                        echo '<input type="hidden" name="mix_id[]" value="' . htmlspecialchars($item['mix_id']) . '">';
                        echo '<input type="hidden" name="sugar_id[]" value="' . htmlspecialchars($item['sugar_id']) . '">';
                    }
                    ?>

                    <button type="submit" class="btn btn-success btn-sm">สั่งซื้ออีกครั้ง</button>
                    </form>
                </div>
            </div>
        </div>
        <?php
            }
        } else {
            echo '<div class="col-12 text-center"><p>ไม่มีประวัติการสั่งซื้อ</p></div>';
        }
        ?>
    </div>
    <!-- ส่วนของการแบ่งหน้า -->
    <nav>
        <ul class="pagination justify-content-center">
            <?php if ($page > 1) { ?>
            <li class="page-item"><a class="page-link" href="?page=<?php echo $page - 1; ?>">ก่อนหน้า</a></li>
            <?php } ?>
            
            <?php for ($i = 1; $i <= $totalPages; $i++) { ?>
            <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
            </li>
            <?php } ?>
            
            <?php if ($page < $totalPages) { ?>
            <li class="page-item"><a class="page-link" href="?page=<?php echo $page + 1; ?>">ถัดไป</a></li>
            <?php } ?>
        </ul>
    </nav>
</div>
</body>
</html>

<?php
// ปิดการเชื่อมต่อฐานข้อมูล
mysqli_close($con);
?>
