<?php
session_start();
include("../condb.php");
include('banner.php');
include('navbar.php');

// ตรวจสอบว่าผู้ใช้ล็อกอินหรือยัง
if (!isset($_SESSION["member_id"])) {
    echo "<div class='alert alert-warning'>กรุณาเข้าสู่ระบบเพื่อดำเนินการสั่งซื้อ</div>";
    echo "<a href='login.php' class='btn btn-warning'>เข้าสู่ระบบ</a>";
    exit();
}

// ดึงข้อมูลสมาชิกจากฐานข้อมูล
$member_id = $_SESSION["member_id"];
$sql = "SELECT m_name, m_tel, m_address FROM tbl_member WHERE member_id = ?";
$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, 'i', $member_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($row = mysqli_fetch_assoc($result)) {
    $m_name = htmlspecialchars($row["m_name"]);
    $m_tel = htmlspecialchars($row["m_tel"]);
    $m_address = htmlspecialchars($row["m_address"]);
} else {
    echo "<div class='alert alert-danger'>ไม่พบข้อมูลผู้ใช้</div>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ชำระเงิน</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .total-price {
            font-size: 1.5rem;
            font-weight: bold;
            color: #28a745;
        }

        .qr-code-container {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 20px;
            margin-top: 30px;
        }

        .btn-block {
            font-size: 1.2rem;
        }

        .cart-item {
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h4 class="mb-4">รายละเอียดสินค้าในตะกร้า</h4>
        <div class="mb-4">
            <ul class="list-group">
                <?php
                $totalPrice = 0;
                if (!empty($_SESSION["cart"])) {
                    foreach ($_SESSION["cart"] as $item) {
                        $sql = "SELECT p_name FROM tbl_product WHERE p_id = ?";
                        $stmt = mysqli_prepare($con, $sql);
                        mysqli_stmt_bind_param($stmt, 'i', $item["p_id"]);
                        mysqli_stmt_execute($stmt);
                        $result = mysqli_stmt_get_result($stmt);
                        $product = mysqli_fetch_assoc($result);
                        $productName = $product ? htmlspecialchars($product["p_name"]) : "ไม่พบชื่อสินค้า";

                        $sugarName = "ไม่ระบุ";
                        if (!empty($item["sugar_id"])) {
                            $stmt = mysqli_prepare($con, "SELECT s_name FROM tbl_sugar WHERE sugar_id = ?");
                            mysqli_stmt_bind_param($stmt, 'i', $item["sugar_id"]);
                            mysqli_stmt_execute($stmt);
                            $result = mysqli_stmt_get_result($stmt);
                            $sugar = mysqli_fetch_assoc($result);
                            $sugarName = htmlspecialchars($sugar["s_name"] ?? "ไม่ระบุ");
                        }

                        $mixName = "ไม่มี";
                        if (!empty($item["mix_id"])) {
                            $stmt = mysqli_prepare($con, "SELECT m_mix FROM tbl_mix WHERE mix_id = ?");
                            mysqli_stmt_bind_param($stmt, 'i', $item["mix_id"]);
                            mysqli_stmt_execute($stmt);
                            $result = mysqli_stmt_get_result($stmt);
                            $mix = mysqli_fetch_assoc($result);
                            $mixName = htmlspecialchars($mix["m_mix"] ?? "ไม่มี");
                        }

                        $toppings = [];
                        if (!empty($item["topping_id"])) {
                            $topping_ids = is_array($item["topping_id"]) ? $item["topping_id"] : explode(",", $item["topping_id"]);
                            foreach ($topping_ids as $topping_id) {
                                $stmt = mysqli_prepare($con, "SELECT t_topping FROM tbl_topping WHERE topping_id = ?");
                                mysqli_stmt_bind_param($stmt, 'i', $topping_id);
                                mysqli_stmt_execute($stmt);
                                $result = mysqli_stmt_get_result($stmt);
                                $topping = mysqli_fetch_assoc($result);
                                if ($topping) {
                                    $toppings[] = htmlspecialchars($topping["t_topping"]);
                                }
                            }
                        }
                        $totalPrice += $item["p_allprice"];
                ?>
                <li class="list-group-item cart-item">
                    <strong>สินค้า:</strong> <?php echo $productName; ?><br>
                    <strong>ระดับความหวาน:</strong> <?php echo $sugarName; ?><br>
                    <strong>การปั่น:</strong> <?php echo $mixName; ?><br>
                    <strong>ท็อปปิ้ง:</strong> <?php echo implode(", ", $toppings) ?: "ไม่มี"; ?><br>
                    <strong>จำนวน:</strong> <?php echo $item["quantity"]; ?><br>
                    <strong>ราคา:</strong> <?php echo number_format($item["p_allprice"], 2); ?> บาท
                </li>
                <?php
                    }
                } else {
                    echo "<li class='list-group-item'>ตะกร้าสินค้าว่าง</li>";
                }
                ?>
            </ul>
        </div>
        <p class="total-price">ราคารวมทั้งหมด: <?php echo number_format($totalPrice, 2); ?> บาท</p>

        <h4 class="mt-4">ข้อมูลการชำระเงิน</h4>
        <form action="process_checkout.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="m_name">ชื่อผู้สั่งซื้อ</label>
                <input type="text" class="form-control" id="m_name" name="m_name" value="<?php echo $m_name; ?>" required>
            </div>
            <div class="form-group">
                <label for="m_tel">เบอร์โทรศัพท์</label>
                <input type="text" class="form-control" id="m_tel" name="m_tel" value="<?php echo $m_tel; ?>" required>
            </div>
            <div class="form-group">
                <label for="delivery_address">ที่อยู่จัดส่ง</label>
                <textarea class="form-control" id="delivery_address" name="delivery_address" rows="3" required><?php echo $m_address; ?></textarea>
            </div>
            <div class="form-group">
                <label for="pay">วิธีการชำระเงิน</label>
                <select class="form-control" id="pay" name="pay" required>
                    <option value="">เลือกวิธีการชำระเงิน</option>
                    <option value="โอนเงิน">โอนเงิน</option>
                    <option value="ปลายทาง">ปลายทาง</option>
                </select>
            </div>

            <div class="qr-code-container text-center">
                <h5>พร้อมเพย์ 0646941561</h5>
                <p>นส.ภัทรวดี กรทรัพย์</p>
                <img src="S__25772036.jpg" alt="พร้อมเพย์ QR Code" class="img-fluid" width="200">
            </div>

            <div class="form-group mt-3">
                <label for="pay_img">อัพโหลดใบเสร็จการชำระเงิน (เฉพาะเมื่อเลือก "โอนเงิน")</label>
                <input type="file" class="form-control-file" id="pay_img" name="pay_img">
            </div>

            <button type="submit" class="btn btn-success btn-block">
                <i class="fas fa-check-circle"></i> ยืนยันคำสั่งซื้อ
            </button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>