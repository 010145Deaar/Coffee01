<?php
session_start();

// ตรวจสอบว่าตะกร้าสินค้าและฟอร์มมีข้อมูลครบถ้วน
if (!isset($_SESSION["cart"])) {
    die("ตะกร้าสินค้าไม่มีสินค้า");
}

if (!isset($_POST["index"]) || !isset($_POST["action"])) {
    die("ข้อมูลไม่ครบถ้วน");
}

// รับค่าจากฟอร์ม
$index = intval($_POST["index"]);
$action = $_POST["action"];

// ตรวจสอบว่าดัชนีสินค้าอยู่ในช่วงที่ถูกต้อง
if (!isset($_SESSION["cart"][$index])) {
    die("ไม่พบสินค้าที่เลือก");
}

// เพิ่มหรือลดจำนวนสินค้า
if ($action === "increase") {
    $_SESSION["cart"][$index]["quantity"] += 1;
} elseif ($action === "decrease") {
    $_SESSION["cart"][$index]["quantity"] -= 1;
    // ลบสินค้าหากจำนวนลดลงเหลือ 0
    if ($_SESSION["cart"][$index]["quantity"] <= 0) {
        unset($_SESSION["cart"][$index]);
        $_SESSION["cart"] = array_values($_SESSION["cart"]); // รีเซ็ตดัชนีใหม่
    }
}

// อัปเดตราคารวมสินค้า
if (isset($_SESSION["cart"][$index])) {
    $_SESSION["cart"][$index]["p_allprice"] = $_SESSION["cart"][$index]["quantity"] * $_SESSION["cart"][$index]["p_price"];
}

// กลับไปหน้าตะกร้าสินค้า
header("Location: cart_page.php");
exit();
?>
