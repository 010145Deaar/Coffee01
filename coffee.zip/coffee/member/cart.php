<?php
session_start();
include("../condb.php");

// ตรวจสอบว่าผู้ใช้ล็อกอินแล้วหรือยัง
if (!isset($_SESSION['member_id'])) {
    header("Location: login.php");
    exit();
}

$member_id = $_SESSION['member_id']; // รหัสสมาชิกที่ล็อกอิน

// ตรวจสอบว่ามีการส่งข้อมูลมาจากฟอร์มหรือไม่
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับข้อมูลจากฟอร์ม
    $p_id = isset($_POST["p_id"]) ? intval($_POST["p_id"]) : 0;
    $p_price = isset($_POST["p_price"]) ? floatval($_POST["p_price"]) : 0.0;
    $sugar_id = isset($_POST["sugar_id"]) ? intval($_POST["sugar_id"]) : null;
    $topping_id = isset($_POST["topping_id"]) ? intval($_POST["topping_id"]) : null;
    $mix_id = isset($_POST["mix_id"]) ? intval($_POST["mix_id"]) : null;

    // สมมุติค่าราคาของ topping, mix, และ sugar
    $topping_price = 10; // ตัวอย่างราคาของ topping ต่อชิ้น
    $mix_price = 15; // ตัวอย่างราคาของ mix ต่อชิ้น
    $sugar_price = 5; // ตัวอย่างราคาของ sugar ต่อชิ้น

    // ตรวจสอบว่าตะกร้าสินค้ามีอยู่ในเซสชันหรือไม่ ถ้าไม่มีก็สร้างใหม่
    if (!isset($_SESSION["cart"])) {
        $_SESSION["cart"] = [];
    }

    // คำนวณราคาเพิ่มเติมจาก topping, mix, และ sugar
    $total_topping_price = is_array($topping_id) ? count($topping_id) * $topping_price : $topping_price;
    $total_mix_price = is_array($mix_id) ? count($mix_id) * $mix_price : $mix_price;
    $total_sugar_price = $sugar_id ? $sugar_price : 0;
    
    // คำนวณราคาสินค้ารวม (p_allprice)
    $p_allprice = $p_price + $total_topping_price + $total_mix_price + $total_sugar_price;

    // สร้าง array สำหรับสินค้า
    $item = [
        "p_id" => $p_id,
        "p_price" => $p_price,
        "sugar_id" => $sugar_id,
        "topping_id" => $topping_id,
        "mix_id" => $mix_id,
        "p_allprice" => $p_allprice,
        "quantity" => 1
    ];

    // ตรวจสอบว่าสินค้านี้อยู่ในตะกร้าหรือยัง
    $exists = false;
    foreach ($_SESSION["cart"] as &$cartItem) {
        if (
            $cartItem["p_id"] == $p_id &&
            $cartItem["sugar_id"] == $sugar_id &&
            $cartItem["topping_id"] == $topping_id &&
            $cartItem["mix_id"] == $mix_id
        ) {
            // ถ้าพบสินค้าแบบเดียวกัน เพิ่มจำนวนสินค้าและอัปเดตราคารวม
            $cartItem["quantity"] += 1;
            $cartItem["p_allprice"] = $cartItem["quantity"] * $cartItem["p_price"];
            $exists = true;
            break;
        }
    }

    // ถ้าไม่มีสินค้าแบบเดียวกันในตะกร้า ให้เพิ่มสินค้าใหม่เข้าไป
    if (!$exists) {
        $_SESSION["cart"][] = $item;
    }

    // เปลี่ยนเส้นทางไปยังหน้าตะกร้าสินค้า
    header("Location: cart_page.php");
    exit();
} else {
    // กรณีที่ไม่ใช่ POST แสดงข้อความผิดพลาด
    die("การเข้าถึงหน้านี้ไม่ถูกต้อง");
}
?>
