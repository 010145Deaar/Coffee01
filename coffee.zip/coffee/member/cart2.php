<?php
session_start();
include('../condb.php'); // เชื่อมต่อฐานข้อมูล

// ตรวจสอบว่าเข้าสู่ระบบแล้วหรือยัง
if (!isset($_SESSION['member_id'])) {
    header("Location: login.php");
    exit();
}

$member_id = $_SESSION['member_id']; // รหัสสมาชิกที่ล็อกอิน

// ตรวจสอบข้อมูลที่ส่งมาจากฟอร์ม
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = $_POST['order_id'] ?? null;
    $total_amount = $_POST['total_amount'] ?? null;
    $p_id = $_POST['p_id'] ?? [];
    $topping_id = $_POST['topping_id'] ?? [];
    $mix_id = $_POST['mix_id'] ?? [];
    $sugar_id = $_POST['sugar_id'] ?? [];

    // ตรวจสอบและจัดระเบียบข้อมูลก่อนบันทึกใน session
    $_SESSION['cart'] = [];

    foreach ($p_id as $index => $product_id) {
        // ดึงข้อมูลราคาสินค้าจากฐานข้อมูล
        $sql = "SELECT p_price FROM tbl_product WHERE p_id = ?";
        $stmt = mysqli_prepare($con, $sql);
        mysqli_stmt_bind_param($stmt, 'i', $product_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $product = mysqli_fetch_assoc($result);

        if (!$product) {
            continue; // ข้ามสินค้าที่ไม่มีข้อมูล
        }

        $basePrice = (float)$product['p_price']; // ราคาเริ่มต้นของสินค้า

        // คำนวณราคาของ topping
        $topping = isset($topping_id[$index]) ? explode(",", $topping_id[$index]) : [];
        $toppingPrice = 0;
        foreach ($topping as $tid) {
            $sqlTopping = "SELECT t_price FROM tbl_topping WHERE topping_id = ?";
            $stmtTopping = mysqli_prepare($con, $sqlTopping);
            mysqli_stmt_bind_param($stmtTopping, 'i', $tid);
            mysqli_stmt_execute($stmtTopping);
            $resultTopping = mysqli_stmt_get_result($stmtTopping);
            $toppingData = mysqli_fetch_assoc($resultTopping);
            $toppingPrice += $toppingData ? (float)$toppingData['t_price'] : 0;
        }

        // คำนวณราคาของ mix
        $mixPrice = 0;
        if (!empty($mix_id[$index])) {
            $sqlMix = "SELECT m_price FROM tbl_mix WHERE mix_id = ?";
            $stmtMix = mysqli_prepare($con, $sqlMix);
            mysqli_stmt_bind_param($stmtMix, 'i', $mix_id[$index]);
            mysqli_stmt_execute($stmtMix);
            $resultMix = mysqli_stmt_get_result($stmtMix);
            $mix = mysqli_fetch_assoc($resultMix);
            $mixPrice = $mix ? (float)$mix['m_price'] : 0;
        }

        // คำนวณราคาสุทธิ (p_allprice) = basePrice + toppingPrice + mixPrice
        $quantityValue = 1; // กำหนดจำนวนเป็น 1 เพราะไม่ได้ระบุในฟอร์มนี้
        $allPrice = ($basePrice + $toppingPrice + $mixPrice) * $quantityValue;

        // เพิ่มข้อมูลลงใน session
        $_SESSION['cart'][] = [
            'p_id' => (int)$product_id,
            'quantity' => $quantityValue,
            'topping_id' => array_map('intval', $topping),
            'mix_id' => isset($mix_id[$index]) ? (int)$mix_id[$index] : null,
            'sugar_id' => isset($sugar_id[$index]) ? (int)$sugar_id[$index] : null,
            'p_allprice' => $allPrice // ราคาสุทธิ
        ];
    }

    // ตรวจสอบว่ามีสินค้าในตะกร้าหรือไม่
    if (empty($_SESSION['cart'])) {
        header("Location: index.php?error=empty_cart");
        exit();
    }

    // ส่งต่อไปยังหน้าแสดงตะกร้าสินค้า
    header("Location: cart_page.php");
    exit();
} else {
    // หากไม่มีการส่งข้อมูล ให้กลับไปยังหน้าประวัติการสั่งซื้อ
    header("Location: index.php");
    exit();
}

// ปิดการเชื่อมต่อฐานข้อมูล
mysqli_close($con);
?>
