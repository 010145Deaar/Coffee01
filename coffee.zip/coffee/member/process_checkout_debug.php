<?php
session_start();
echo "<h1>ตรวจสอบค่าที่ส่งมา</h1>";

// ตรวจสอบว่ามีการส่งค่าผ่าน POST หรือไม่
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    echo "<h3>ข้อมูลที่ส่งมาใน POST:</h3>";
    if (!empty($_POST)) {
        echo "<pre>";
        print_r($_POST);
        echo "</pre>";
    } else {
        echo "<p>ไม่มีข้อมูลใน POST</p>";
    }

    echo "<h3>ข้อมูลตะกร้าสินค้าใน SESSION:</h3>";
    if (isset($_SESSION["cart"]) && !empty($_SESSION["cart"])) {
        echo "<pre>";
        print_r($_SESSION["cart"]);
        echo "</pre>";
    } else {
        echo "<p>ตะกร้าสินค้าว่างเปล่าหรือไม่มีการตั้งค่า</p>";
    }
} else {
    echo "<p>ไม่ได้ส่งค่าจากฟอร์ม</p>";
}
?>
