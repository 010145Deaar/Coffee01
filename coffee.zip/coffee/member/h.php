<?php
session_start();
include("../condb.php");  // รวมไฟล์ condb.php ที่ใช้เชื่อมต่อฐานข้อมูล

$member_id = $_SESSION['member_id'];
$m_name = $_SESSION['m_name'];
$m_level = $_SESSION['m_level'];

// ตรวจสอบระดับผู้ใช้
if($m_level != 'member') {
    Header("Location: ../logout.php");
    exit();
}

// เปิดบัฟเฟอร์เอาต์พุต
ob_start();

// แสดงข้อมูลใน $_SESSION แต่ไม่ให้แสดงในหน้าเว็บ
print_r($_SESSION);

// ล้างบัฟเฟอร์เอาต์พุต เพื่อไม่ให้แสดงผล
ob_end_clean();

if (isset($_SESSION['member_id'])) {
    $member_id = $_SESSION['member_id'];
    $m_name = $_SESSION['m_name'];
    $m_level = $_SESSION['m_level'];
    $m_img = $_SESSION['m_img'];

    // ตรวจสอบระดับผู้ใช้
    if ($m_level != 'member') {
        header("Location: ../logout.php");
        exit();
    }

    // เริ่มต้นการทำงานของ Transaction
    mysqli_begin_transaction($con);

    try {
        // สร้าง SQL query เพื่อตรวจสอบข้อมูลสมาชิก
        $sql = "SELECT * FROM tbl_member WHERE member_id = '$member_id'";  // ใช้ '' ห่อหุ้มตัวแปรตัวเลขเพื่อป้องกัน SQL injection
        $result = mysqli_query($con, $sql);

        // ตรวจสอบว่ามีผลลัพธ์หรือไม่
        if ($row = mysqli_fetch_assoc($result)) {
            // Extract ข้อมูลที่ดึงมา
            $m_name = $row['m_name'];
            $m_img = $row['m_img'];
        } else {
            // ถ้าไม่มีข้อมูลแสดงข้อผิดพลาด
            echo "ไม่พบข้อมูลสมาชิก";
            mysqli_rollback($con);  // ยกเลิกการทำงานทั้งหมดในกรณีนี้
            exit();
        }

        // ถ้าทุกคำสั่งสำเร็จ ให้ commit การเปลี่ยนแปลง
        mysqli_commit($con);
    } catch (Exception $e) {
        // ถ้าเกิดข้อผิดพลาด ให้ rollback การเปลี่ยนแปลงทั้งหมด
        mysqli_rollback($con);
        echo "Error: " . $e->getMessage();
    }
} else {
    echo "ไม่พบ session ของสมาชิก";
}
?>

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Coffee Shop</title>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<!-- เปลี่ยน favicon ที่นี่ -->
<link rel="icon" href="../coffee.png" type="type="image/png"">
    
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
