<?php
session_start();
require_once('../condb.php');

// ตรวจสอบว่าผู้ใช้เข้าสู่ระบบหรือยัง
if (!isset($_SESSION['m_level']) || $_SESSION['m_level'] != 'member') {
    header("Location: index.php");
    exit();
}

// ดึงข้อมูลประเภทสินค้า
$query_typeprd = "SELECT * FROM tbl_type ORDER BY type_id ASC";
$typeprd = mysqli_query($con, $query_typeprd) or die("Error in query: $query_typeprd " . mysqli_error($con));

// กำหนดค่าเริ่มต้นสำหรับข้อมูลสมาชิก
$m_name = isset($_SESSION['m_name']) ? htmlspecialchars($_SESSION['m_name'], ENT_QUOTES, 'UTF-8') : 'Guest';
$member_id = isset($_SESSION['member_id']) ? $_SESSION['member_id'] : null;
$m_img = isset($_SESSION['m_img']) ? $_SESSION['m_img'] : 'default.png';
?>

<div class="container-fluid">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <div class="row">
        <div class="col-12">
            <nav class="navbar navbar-expand-lg navbar-light" style="background-color: #FFFFFF;">
                <a class="navbar-brand" href="member_profile.php">
                    <img src="../m_img/<?php echo $m_img; ?>" width="30" height="30" class="d-inline-block align-top" alt="โปรไฟล์">
                    <span class="text-black">คุณ <?php echo $m_name; ?></span>
                </a>
                <a class="btn btn-light" href="index.php" role="button">หน้าหลัก</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <div class="btn-group">
                            <button type="button" class="btn btn-light dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                ประเภทสินค้า
                            </button>
                            <div class="dropdown-menu">
                                <?php if (mysqli_num_rows($typeprd) > 0): ?>
                                    <?php while ($row_typeprd = mysqli_fetch_assoc($typeprd)): ?>
                                        <a href="index.php?type_id=<?php echo $row_typeprd['type_id']; ?>" class="dropdown-item">
                                            <?php echo htmlspecialchars($row_typeprd['type_name'], ENT_QUOTES, 'UTF-8'); ?>
                                        </a>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <a class="dropdown-item disabled">ไม่มีข้อมูลประเภทสินค้า</a>
                                <?php endif; ?>
                            </div>
                        </div>

                        <?php if ($member_id): ?>
                            <li class="nav-item">
                                <a class="btn btn-light" href="../logout.php" role="button" onclick="return confirm('คุณต้องการออกจากระบบหรือไม่ ?')">ออกจากระบบ</a>
                            </li>
                        <?php else: ?>
                            <div class="btn-group">
                                <a class="btn btn-light" href="form_login.php" role="button">เข้าสู่ระบบ</a>
                            </div>
                        <?php endif; ?>
                    </ul>

                    <a href="time.php" class="btn btn-success text-white my-2 my-sm-0">
                        <i class=""></i> ดูคำสั่งซื้อ
                    </a>
                    
                    <!-- ปุ่มไปยังหน้า cart.php -->
                    <a href="cart_page.php" class="btn btn-primary text-white my-2 my-sm-0">
                        <i class="fas fa-shopping-cart"></i> ดูรถเข็น
                    </a>

                    <!-- ฟอร์มค้นหา -->
                    <form class="form-inline my-2 my-lg-0" action="index.php" method="GET">
                        <input class="form-control mr-sm-2" type="text" placeholder="ค้นหาสินค้า" name="q" value="<?php echo isset($_GET['q']) ? htmlspecialchars($_GET['q'], ENT_QUOTES, 'UTF-8') : ''; ?>">
                        <button class="btn btn-success text-White my-2 my-sm-0" type="submit">ค้นหา</button>
                    </form>
                </div>
            </nav>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
