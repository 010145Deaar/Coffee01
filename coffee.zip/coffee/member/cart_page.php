<?php
session_start();
include("../condb.php");
?>

<?php 
include('banner.php');
include('navbar.php');
?>

<?php include('footerjs.php'); ?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="mystyle.css">
    <title>ตะกร้าสินค้า</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .cart-items-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .cart-item {
            border: 1px solid #ddd;
            padding: 20px;
            border-radius: 10px;
            background-color: #f9f9f9;
            box-sizing: border-box;
            width: 100%;
        }
        .cart-item h5 {
            font-size: 1.2rem;
            font-weight: bold;
        }
        .cart-item .item-actions {
            margin-top: 10px;
            display: flex;
            justify-content: space-between;
        }
        .total-price {
            font-size: 1.5rem;
            font-weight: bold;
            margin-top: 20px;
        }
        .cart-buttons {
            margin-top: 20px;
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        @media (min-width: 576px) {
            .cart-item {
                width: 48%;
            }
        }
        @media (min-width: 768px) {
            .cart-item {
                width: 30%;
            }
        }
        @media (min-width: 992px) {
            .cart-item {
                width: 22%;
            }
        }
    </style>
</head>
<body>
    <?php
    if (!isset($_SESSION["cart"]) || !is_array($_SESSION["cart"]) || count($_SESSION["cart"]) === 0) {
        echo "<div class='container mt-5'><p class='text-center'>ตะกร้าสินค้าว่างเปล่า</p></div>";
        exit();
    }
    ?>
    
    <div class="container mt-5">
        <h2 class="mb-4">ตะกร้าสินค้า</h2>

        <div class="cart-items-container">
        <?php
        $totalPrice = 0; // ตัวแปรสำหรับเก็บราคารวมทั้งหมด
        foreach ($_SESSION["cart"] as $index => $item):
            $stmt = mysqli_prepare($con, "SELECT p_name, p_price FROM tbl_product WHERE p_id = ?");
            if (!$stmt) {
                die("ข้อผิดพลาด SQL: " . mysqli_error($con));
            }
            mysqli_stmt_bind_param($stmt, 'i', $item["p_id"]);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $product = mysqli_fetch_assoc($result);
            $productName = $product["p_name"] ?? "ไม่พบชื่อสินค้า";
            $productPrice = $product["p_price"] ?? 0;

            $item["p_allprice"] = $item["quantity"] * $productPrice;
            $totalPrice += $item["p_allprice"];
        ?>

        <div class="cart-item">
            <h5><?php echo htmlspecialchars($productName); ?></h5>
            <p>ราคาต่อหน่วย: <?php echo number_format($productPrice, 2); ?> บาท</p>
            <p>ระดับความหวาน: 
                <?php
                if (!empty($item["sugar_id"])) {
                    $stmt = mysqli_prepare($con, "SELECT s_name FROM tbl_sugar WHERE sugar_id = ?");
                    mysqli_stmt_bind_param($stmt, 'i', $item["sugar_id"]);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    $sugar = mysqli_fetch_assoc($result);
                    echo htmlspecialchars($sugar["s_name"] ?? "ไม่ระบุ");
                } else {
                    echo "ไม่ระบุ";
                }
                ?>
            </p>
            <p>ท็อปปิ้ง:  
   <?php
   // ตรวจสอบก่อนว่าค่า topping_id มีข้อมูลหรือไม่
   if (!empty($item["topping_id"])) {
       // ตรวจสอบรูปแบบของ topping_id
       $topping_id = is_array($item["topping_id"]) ? $item["topping_id"] : explode(",", $item["topping_id"]);

       // เตรียมข้อความสำหรับแสดงท็อปปิ้ง
       $toppingTexts = [];

       // วนลูปดึงข้อมูลจากฐานข้อมูล
       foreach ($topping_id as $topping_id) {
           $stmt = mysqli_prepare($con, "SELECT t_topping FROM tbl_topping WHERE topping_id = ?");
           if ($stmt) {
               mysqli_stmt_bind_param($stmt, 'i', $topping_id);
               mysqli_stmt_execute($stmt);
               $result = mysqli_stmt_get_result($stmt);
               $topping = mysqli_fetch_assoc($result);
               
               // เพิ่มชื่อท็อปปิ้งในรายการ
               if ($topping) {
                   $toppingTexts[] = htmlspecialchars($topping["t_topping"]);
               } else {
                   $toppingTexts[] = "ไม่พบข้อมูล"; // หากไม่มีข้อมูลในฐานข้อมูล
               }
           }
       }

       // แสดงผลรายการท็อปปิ้ง
       echo implode(", ", $toppingTexts);
   } else {
       // หากไม่มี topping_id
       echo "ไม่มี";
   }
   ?>
</p>
        </p>
            <p>การปั่น: 
                <?php
                if (!empty($item["mix_id"])) {
                    $stmt = mysqli_prepare($con, "SELECT m_mix FROM tbl_mix WHERE mix_id = ?");
                    mysqli_stmt_bind_param($stmt, 'i', $item["mix_id"]);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    $mix = mysqli_fetch_assoc($result);
                    echo htmlspecialchars($mix["m_mix"] ?? "ไม่มี");
                } else {
                    echo "ไม่มี";
                }
                ?>
            </p>
            <p>
                จำนวน: 
                <form action="update_cart.php" method="POST" class="d-inline">
                    <input type="hidden" name="index" value="<?php echo $index; ?>">
                    <button type="submit" name="action" value="decrease" class="btn btn-sm btn-warning">-</button>
                </form>
                <span><?php echo $item["quantity"] ?? 1; ?></span>
                <form action="update_cart.php" method="POST" class="d-inline">
                    <input type="hidden" name="index" value="<?php echo $index; ?>">
                    <button type="submit" name="action" value="increase" class="btn btn-sm btn-success">+</button>
                </form>
            </p>
            <p>ราคารวม: <?php echo number_format($item["p_allprice"], 2); ?> บาท</p>
            <div class="item-actions">
                <a href="remove_item.php?index=<?php echo $index; ?>" class="btn btn-danger btn-sm">ลบ</a>
            </div>
        </div>

        <?php endforeach; ?>
        </div>

        <div class="total-price text-right">
            <strong>ราคารวมทั้งหมด: <?php echo number_format($totalPrice, 2); ?> บาท</strong>
        </div>

        <div class="cart-buttons">
            <a href="index.php" class="btn btn-primary">เลือกสินค้าต่อ</a>
            <a href="checkout.php" class="btn btn-success">ดำเนินการชำระเงิน</a>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
