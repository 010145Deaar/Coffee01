<?php
session_start();
include('../condb.php');

// ตรวจสอบสิทธิ์การเข้าถึง
if ($_SESSION['m_level'] != 'admin') {
    Header("Location: index.php");
    exit();
}

// รับค่าจากฟอร์ม
$topping_id = mysqli_real_escape_string($con, $_POST['topping_id']);
$t_topping = mysqli_real_escape_string($con, $_POST['t_topping']);
$t_price = mysqli_real_escape_string($con, $_POST['t_price']);

// อัปเดตข้อมูลใน `tbl_topping`
$sql = "UPDATE tbl_topping SET t_topping = '$t_topping', m_price = '$m_price' WHERE topping_id = $topping_id";
$result = mysqli_query($con, $sql) or die("Error in query: $sql " . mysqli_error($con));

// ตรวจสอบผลลัพธ์
if ($result) {
    echo "<script type='text/javascript'>";
    echo "alert('แก้ไขข้อมูลสำเร็จ!');";
    echo "window.location = 'topping.php';";
    echo "</script>";
} else {
    echo "<script type='text/javascript'>";
    echo "alert('เกิดข้อผิดพลาดในการแก้ไขข้อมูล');";
    echo "window.location = 'topping.php';";
    echo "</script>";
}

mysqli_close($con);
?>
