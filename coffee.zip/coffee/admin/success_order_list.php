<div class="box-header">
  <h3 class="box-title">รายการสั่งซื้อ</h3>
</div>
<div class="box-body">
  <!-- เพิ่มคลาส Bootstrap เพื่อให้ responsive -->
  <div class="table-responsive">
    <table id="example1" class="table table-bordered table-striped table-hover">
      <thead>
        <tr>
          <th style="width: 5%;">#</th>
          <th style="width: 10%;">รหัสคำสั่งซื้อ</th>
          <th style="width: 15%;">สมาชิก</th>
          <th style="width: 25%;">สินค้า</th>
          <th style="width: 10%;">จำนวนเงินรวม</th>
          <th style="width: 10%;">สถานะ</th>
          <th style="width: 10%;">วันที่สั่งซื้อ</th>
          <th style="width: 15%;">ที่อยู่จัดส่ง</th>
          <th style="width: 10%;">ชำระเงิน</th>
          <th style="width: 10%;">จัดการ</th>
        </tr>
      </thead>
      <tbody>
        <?php
        include('../condb.php'); // เชื่อมต่อฐานข้อมูล

        // แก้ไข SQL Query เพื่อดึงข้อมูล pay และ pay_img จากตาราง orders
            $sql = "SELECT o.*, 
            m.m_name, 
            o.phone_number,  -- ดึงเบอร์โทรจากตาราง orders
            GROUP_CONCAT(
            CONCAT(
                p.p_name, ' x', od.quantity, 
                IF(t.t_topping IS NOT NULL, CONCAT(' (Topping: ', t.t_topping, ')'), ''), 
                IF(mx.m_mix IS NOT NULL, CONCAT(' (Mix: ', mx.m_mix, ')'), ''), 
                IF(s.s_name IS NOT NULL, CONCAT(' (Sugar: ', s.s_name, ')'), '')
            ) 
            SEPARATOR '<br>' ) AS product_list
    FROM orders o 
    LEFT JOIN tbl_member m ON o.member_id = m.member_id
    LEFT JOIN order_details od ON o.order_id = od.order_id
    LEFT JOIN tbl_product p ON od.p_id = p.p_id
    LEFT JOIN tbl_topping t ON od.topping_id = t.topping_id
    LEFT JOIN tbl_mix mx ON od.mix_id = mx.mix_id
    LEFT JOIN tbl_sugar s ON od.sugar_id = s.sugar_id
    WHERE o.status = 'เสร็จสิ้น'  -- เพิ่มเงื่อนไขสถานะ
    GROUP BY o.order_id
    ORDER BY o.order_date DESC";

        $result = mysqli_query($con, $sql);

        if ($result && mysqli_num_rows($result) > 0) {
          $i = 1;
          while ($row = mysqli_fetch_assoc($result)) {
        ?>
        <tr>
          <td><?php echo $i++; ?></td>
          <td><?php echo $row['order_id']; ?></td>
          <td>
            <?php echo $row['m_name']; ?><br>
            <small><?php echo $row['phone_number']; ?></small> <!-- แสดงเบอร์โทรจากคอลัมน์ phone_number ในตาราง orders -->
          </td>
          <td><?php echo $row['product_list']; ?></td>
          <td><?php echo number_format($row['total_amount'], 2); ?></td>
          <td><?php echo $row['status']; ?></td>
          <td><?php echo date('Y-m-d H:i:s', strtotime($row['order_date'])); ?></td>
          <td><?php echo $row['delivery_address']; ?></td>
          <td>
          <?php
          // แสดงสถานะการชำระเงินโดยตรงจากฐานข้อมูล
          if ($row['pay'] === 'ชำระเงินแล้ว') {
              echo '<span class="badge bg-success">' . $row['pay'] . '</span>';
          } elseif ($row['pay'] === 'ปลายทาง') {
              echo '<span class="badge bg-warning">' . $row['pay'] . '</span>';
          } else {
              echo '<span class="badge bg-danger">' . $row['pay'] . '</span>';
          }

          // แสดงรูปภาพใบเสร็จ (ถ้ามี)
          if (!empty($row['pay_img'])) {
              echo '<br><img src="../uploads/' . htmlspecialchars($row['pay_img']) . '" alt="Payment Proof" style="width: 100px; height: auto; margin-top: 5px;">';
          }
          ?>
        </td>
        <td>
            <!-- ปุ่มดูรายละเอียดคำสั่งซื้อ -->
            <a href="order_form_edit.php?act=edit&id=<?php echo htmlspecialchars($row['order_id']); ?>" class="btn btn-info btn-sm">แก้ไขรายละเอียด</a>
        </td>
        </tr>
        <?php
            }
        } else {
            echo '<tr><td colspan="10" class="text-center">ไม่มีข้อมูล</td></tr>';
        }
        ?>
        
      </tbody>
    </table>
  </div>
</div>
