<?php
session_start();
echo '<meta charset="utf-8">';
include('../condb.php');

// ตรวจสอบสิทธิ์การเข้าถึง
if ($_SESSION['m_level'] != 'admin') {
    Header("Location: index.php");
    exit();
}

// รับข้อมูลจากฟอร์มและใช้ mysqli_real_escape_string เพื่อป้องกัน SQL Injection
$member_id = mysqli_real_escape_string($con, $_POST["member_id"]);
$m_level = mysqli_real_escape_string($con, $_POST["m_level"]);
$m_user = mysqli_real_escape_string($con, $_POST["m_user"]);
$m_name = mysqli_real_escape_string($con, $_POST["m_name"]);
$m_tel = mysqli_real_escape_string($con, $_POST["m_tel"]);
$m_email = mysqli_real_escape_string($con, $_POST["m_email"]);
$m_address = mysqli_real_escape_string($con, $_POST["m_address"]);
$m_img2 = mysqli_real_escape_string($con, $_POST["m_img2"]);

// ตั้งชื่อไฟล์รูปภาพใหม่ หากมีการอัปโหลดรูปใหม่
$date1 = date("Ymd_His");
$numrand = (mt_rand());
$upload = $_FILES['m_img']['name'];

if ($upload != '') { 
    $path = "../m_img/";
    $type = strrchr($_FILES['m_img']['name'], ".");
    $newname = $numrand . $date1 . $type;
    $path_copy = $path . $newname;

    // ย้ายไฟล์ไปยังโฟลเดอร์ที่กำหนด
    if (move_uploaded_file($_FILES['m_img']['tmp_name'], $path_copy)) {
        $m_img = $newname;
    } else {
        echo '<script>';
        echo "alert('ไม่สามารถอัปโหลดรูปภาพได้');";
        echo "window.location='member.php?act=edit&member_id=$member_id';";
        echo '</script>';
        exit();
    }
} else {
    $m_img = $m_img2; // ใช้รูปเดิมหากไม่มีการอัปโหลดใหม่
}

// สร้างคำสั่ง SQL สำหรับอัปเดตข้อมูลสมาชิก
$sql = "UPDATE tbl_member SET 
            m_level = '$m_level',
            m_user = '$m_user',
            m_name = '$m_name',
            m_tel = '$m_tel',
            m_email = '$m_email',
            m_address = '$m_address',
            m_img = '$m_img'
        WHERE member_id = '$member_id'";

// ตรวจสอบผลลัพธ์การอัปเดต
$result = mysqli_query($con, $sql);

if ($result) {
    echo '<script>';
    echo "window.location='member.php?do=finish';";
    echo '</script>';
} else {
    echo '<script>';
    echo "alert('เกิดข้อผิดพลาด: " . mysqli_error($con) . "');";
    echo "window.location='member.php?act=edit&member_id=$member_id';";
    echo '</script>';
}

mysqli_close($con);
?>
