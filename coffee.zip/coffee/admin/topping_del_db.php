<?php
session_start();
include('../condb.php');

// ตรวจสอบสิทธิ์การเข้าถึง
if ($_SESSION['m_level'] != 'admin') {
    Header("Location: index.php");
    exit();
}

// รับค่า ID จาก GET และป้องกัน SQL Injection
$ID = mysqli_real_escape_string($con, $_GET["ID"]);

// เริ่มกระบวนการลบข้อมูล
mysqli_autocommit($con, false); // ปิดการทำงานแบบอัตโนมัติ

try {
    // ลบข้อมูลใน tbl_topping 
    $sql_topping = "DELETE FROM tbl_topping WHERE topping_id = $ID";
    $result_topping = mysqli_query($con, $sql_topping);
    if (!$result_topping) {
        throw new Exception("Error deleting data from tbl_topping: " . mysqli_error($con));
    }

    // หากสำเร็จ ให้ commit การลบ
    mysqli_commit($con);

    // แสดงข้อความสำเร็จและเปลี่ยนเส้นทาง
    echo "<script type='text/javascript'>";
    echo "alert('ลบข้อมูลสำเร็จ!');";
    echo "window.location = 'topping.php'; "; // หรือเปลี่ยนเป็น topping.php หากต้องการเปลี่ยนหน้า
    echo "</script>";
} catch (Exception $e) {
    // หากเกิดข้อผิดพลาด ให้ rollback การลบทั้งหมด
    mysqli_rollback($con);

    // แสดงข้อความข้อผิดพลาด
    echo "<script type='text/javascript'>";
    echo "alert('เกิดข้อผิดพลาด: " . $e->getMessage() . "');";
    echo "window.location = 'topping.php'; ";
    echo "</script>";
}

// ปิดการเชื่อมต่อฐานข้อมูล
mysqli_close($con);
?>
