<?php
// เชื่อมต่อฐานข้อมูล
include('../condb.php');

// ตรวจสอบว่ามีข้อมูลส่งมาจากฟอร์มหรือไม่
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // รับข้อมูลจากฟอร์ม
    $order_id = intval($_POST['order_id']); // กรองค่า order_id ให้เป็นตัวเลข
    $delivery_address = mysqli_real_escape_string($con, $_POST['delivery_address']);
    $status = mysqli_real_escape_string($con, $_POST['status']);
    $pay = mysqli_real_escape_string($con, $_POST['pay']);
    
    // ตรวจสอบว่ามีไฟล์อัปโหลดมาหรือไม่
    if (!empty($_FILES['pay_img']['name'])) {
        $target_dir = "../uploads/";
        $file_name = basename($_FILES['pay_img']['name']);
        $target_file = $target_dir . $file_name;

        // ตรวจสอบชนิดของไฟล์
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];

        if (!in_array($file_type, $allowed_types)) {
            echo "<script>alert('อนุญาตเฉพาะไฟล์รูปภาพ (JPG, JPEG, PNG, GIF)'); window.history.back();</script>";
            exit();
        }

        // อัปโหลดไฟล์
        if (move_uploaded_file($_FILES['pay_img']['tmp_name'], $target_file)) {
            // หากอัปโหลดสำเร็จ
            $pay_img = $file_name;
        } else {
            echo "<script>alert('เกิดข้อผิดพลาดในการอัปโหลดรูปภาพ'); window.history.back();</script>";
            exit();
        }
    } else {
        // หากไม่มีการอัปโหลดไฟล์ใหม่ ให้คงค่าภาพเดิม
        $pay_img = mysqli_real_escape_string($con, $_POST['existing_pay_img'] ?? '');
    }

    // อัปเดตคำสั่งซื้อในฐานข้อมูล
    $sql = "UPDATE orders 
            SET delivery_address = '$delivery_address', 
                status = '$status', 
                pay = '$pay', 
                pay_img = '$pay_img'
            WHERE order_id = $order_id";

    if (mysqli_query($con, $sql)) {
        echo "<script>alert('อัปเดตคำสั่งซื้อเรียบร้อยแล้ว'); window.location.href='order.php';</script>";
    } else {
        echo "<script>alert('เกิดข้อผิดพลาด: " . mysqli_error($con) . "'); window.history.back();</script>";
    }
} else {
    // หากไม่มีการส่งข้อมูลผ่าน POST ให้กลับไปยังหน้ารายการคำสั่งซื้อ
    echo "<script>alert('ไม่พบข้อมูลที่ต้องการอัปเดต'); window.location.href='order.php';</script>";
    exit();
}
?>
