<?php include('h.php'); ?>
<body class="hold-transition skin-purple sidebar-mini">
  <div class="wrapper">
    <!-- Main Header -->
    <?php include('menutop.php'); ?>
    <?php include('menu_l.php'); ?>
    <div class="content-wrapper">
      <section class="content-header">
        <h1>
          <i class="glyphicon glyphicon-check hidden-xs"></i> 
          <span class="hidden-xs">ข้อมูลคำสั่งซื้อที่เสร็จสิ้นแล้ว</span> 
        </h1>
      </section>
      <section class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="box">
              <div class="row">
                <div class="col-sm-12">
                  <div class="box-body">
                  <?php
                  $act = isset($_GET['act']) ? $_GET['act'] : '';
                  $ID = isset($_GET['ID']) ? $_GET['ID'] : '';

                  if ($act == 'edit' && !empty($ID)) {
                      include('order_form_edit.php');
                  } else {
                      include('success_order_list.php');
                  }
                  ?>                  
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    <?php include('footerjs.php'); ?>
  </div>
</body>
</html>
