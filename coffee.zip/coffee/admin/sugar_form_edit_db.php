<?php
session_start();
echo '<meta charset="utf-8">';
include('../condb.php');

if ($_SESSION['m_level'] != 'admin') {
    Header("Location: index.php");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // รับค่าจากฟอร์ม
    $sugar_id = mysqli_real_escape_string($con, $_POST['sugar_id']);
    $s_name = mysqli_real_escape_string($con, $_POST["s_name"]);

    // ตรวจสอบค่าที่ได้รับว่าถูกต้องหรือไม่
    if (empty($s_name)) {
        echo '<script>';
        echo 'swal("กรุณากรอกชื่อระดับความหวาน", "", "warning");';
        echo '</script>';
        exit();
    }

    // SQL สำหรับการอัพเดตข้อมูล
    $sql = "UPDATE tbl_sugar SET s_name='$s_name' WHERE sugar_id=$sugar_id";

    // Execute query และตรวจสอบผลลัพธ์
    $result = mysqli_query($con, $sql);
    mysqli_close($con);

    if ($result) {
        echo '<script>';
        echo "window.location='sugar.php?do=finish';";
        echo '</script>';
    } else {
        echo '<script>';
        echo "window.location='sugar.php?act=add&do=f';";
        echo '</script>';
    }
}
?>
