<?php
// เชื่อมต่อฐานข้อมูล
include('../condb.php');

// ตรวจสอบว่ามีการส่งค่า `id` มาหรือไม่
if (isset($_GET['id'])) {
    $order_id = intval($_GET['id']); // กรองตัวเลขเพื่อความปลอดภัย
} else {
    echo "<script>alert('ไม่พบคำสั่งซื้อที่ต้องการแก้ไข'); window.location.href='orders_list.php';</script>";
    exit();
}

// ดึงข้อมูลคำสั่งซื้อที่ต้องการแก้ไข
$sql_order = "SELECT o.*, m.m_name 
              FROM orders o 
              LEFT JOIN tbl_member m ON o.member_id = m.member_id 
              WHERE o.order_id = $order_id";
$result_order = mysqli_query($con, $sql_order);

if (!$result_order || mysqli_num_rows($result_order) == 0) {
    echo "<script>alert('ไม่พบคำสั่งซื้อในระบบ'); window.location.href='orders_list.php';</script>";
    exit();
}

$order = mysqli_fetch_assoc($result_order);

// ดึงข้อมูลสินค้าในคำสั่งซื้อ
$sql_details = "SELECT od.*, p.p_name, t.t_topping, mx.m_mix, s.s_name 
                FROM order_details od
                LEFT JOIN tbl_product p ON od.p_id = p.p_id
                LEFT JOIN tbl_topping t ON od.topping_id = t.topping_id
                LEFT JOIN tbl_mix mx ON od.mix_id = mx.mix_id
                LEFT JOIN tbl_sugar s ON od.sugar_id = s.sugar_id
                WHERE od.order_id = $order_id";
$result_details = mysqli_query($con, $sql_details);
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แก้ไขรายการคำสั่งซื้อ</title>
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="hold-transition skin-purple sidebar-mini">
    <div class="wrapper">
        <!-- Main Header -->
       

        <div class="content-wrapper">
            <section class="content-header">
                <h1 class="text-center">
                    <i class="glyphicon glyphicon-check"></i> 
                    แก้ไขคำสั่งซื้อ #<?php echo htmlspecialchars($order['order_id']); ?>
                </h1>
            </section>
            <section class="content">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-8 col-md-10 col-sm-12 mx-auto">
                            <div class="card shadow-sm">
                                <div class="card-body">
                                    <form action="order_update.php" method="post" enctype="multipart/form-data">
                                        <input type="hidden" name="order_id" value="<?php echo htmlspecialchars($order['order_id']); ?>">

                                        <div class="mb-3">
                                            <label for="member_name" class="form-label">สมาชิก</label>
                                            <input type="text" class="form-control" id="member_name" value="<?php echo htmlspecialchars($order['m_name']); ?>" disabled>
                                        </div>

                                        <div class="mb-3">
                                            <label for="delivery_address" class="form-label">ที่อยู่จัดส่ง</label>
                                            <textarea class="form-control" id="delivery_address" name="delivery_address" rows="3" required><?php echo htmlspecialchars($order['delivery_address']); ?></textarea>
                                        </div>

                                        <div class="mb-3">
                                            <label for="status" class="form-label">สถานะคำสั่งซื้อ</label>
                                            <select class="form-select" id="status" name="status" required>
                                                <option value="กำลังดำเนินการ" <?php echo $order['status'] === 'กำลังดำเนินการ' ? 'selected' : ''; ?>>กำลังดำเนินการ</option>
                                                <option value="กำลังจัดส่ง" <?php echo $order['status'] === 'กำลังจัดส่ง' ? 'selected' : ''; ?>>กำลังจัดส่ง</option>
                                                <option value="เสร็จสิ้น" <?php echo $order['status'] === 'เสร็จสิ้น' ? 'selected' : ''; ?>>เสร็จสิ้น</option>
                                                <option value="ยกเลิก" <?php echo $order['status'] === 'ยกเลิก' ? 'selected' : ''; ?>>ยกเลิก</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label for="pay" class="form-label">สถานะการชำระเงิน</label>
                                            <select class="form-select" id="pay" name="pay" required>
                                                <option value="ชำระเงินแล้ว" <?php echo $order['pay'] === 'ชำระเงินแล้ว' ? 'selected' : ''; ?>>ชำระเงินแล้ว</option>
                                                <option value="ปลายทาง" <?php echo $order['pay'] === 'ปลายทาง' ? 'selected' : ''; ?>>ปลายทาง</option>
                                                <option value="ยังไม่ได้ชำระเงิน" <?php echo $order['pay'] === 'ยังไม่ได้ชำระเงิน' ? 'selected' : ''; ?>>ยังไม่ได้ชำระเงิน</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <label for="pay_img" class="form-label">หลักฐานการชำระเงิน (ถ้ามี)</label>
                                            <?php if (!empty($order['pay_img'])): ?>
                                                <img src="../uploads/<?php echo htmlspecialchars($order['pay_img']); ?>" alt="Payment Proof" class="img-fluid mb-3" style="max-width: 200px;">
                                            <?php endif; ?>
                                            <input type="file" class="form-control" id="pay_img" name="pay_img">
                                        </div>

                                        <h5 class="mt-4">รายละเอียดสินค้า</h5>
                                        <div class="table-responsive">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>ชื่อสินค้า</th>
                                                        <th>จำนวน</th>
                                                        <th>ราคา</th>
                                                        <th>ท็อปปิ้ง</th>
                                                        <th>มิกซ์</th>
                                                        <th>ระดับความหวาน</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php if (mysqli_num_rows($result_details) > 0): ?>
                                                        <?php $i = 1; while ($detail = mysqli_fetch_assoc($result_details)): ?>
                                                            <tr>
                                                                <td><?php echo $i++; ?></td>
                                                                <td><?php echo htmlspecialchars($detail['p_name']); ?></td>
                                                                <td><?php echo $detail['quantity']; ?></td>
                                                                <td><?php echo number_format($detail['price'], 2); ?></td>
                                                                <td><?php echo htmlspecialchars($detail['t_topping']); ?></td>
                                                                <td><?php echo htmlspecialchars($detail['m_mix']); ?></td>
                                                                <td><?php echo htmlspecialchars($detail['s_name']); ?></td>
                                                            </tr>
                                                        <?php endwhile; ?>
                                                    <?php else: ?>
                                                        <tr>
                                                            <td colspan="7" class="text-center">ไม่มีข้อมูลสินค้าในคำสั่งซื้อ</td>
                                                        </tr>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>
                                        </div>

                                        <div class="d-flex justify-content-between mt-4">
                                            <a href="order.php" class="btn btn-secondary">กลับ</a>
                                            <button type="submit" class="btn btn-success">บันทึก</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <?php include('footerjs.php'); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
</body>
</html>
