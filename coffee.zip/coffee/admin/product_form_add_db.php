<?php
session_start();
echo '<meta charset="utf-8">';
include('../condb.php');

// ตรวจสอบว่าผู้ใช้มีสิทธิ์เป็นผู้ดูแลระบบ
if ($_SESSION['m_level'] != 'admin') {
    Header("Location: index.php");
}

// รับค่าจากฟอร์ม
$p_name = mysqli_real_escape_string($con, $_POST["p_name"]);
$type_id = mysqli_real_escape_string($con, $_POST["type_id"]);
$topping_id = mysqli_real_escape_string($con, $_POST["topping_id"]);
$mix_id = mysqli_real_escape_string($con, $_POST["mix_id"]);
$p_detail = mysqli_real_escape_string($con, $_POST["p_detail"]);
$p_price = mysqli_real_escape_string($con, $_POST["p_price"]);
$sugar_id = mysqli_real_escape_string($con, $_POST["sugar_id"]);
$p_allprice = mysqli_real_escape_string($con, $_POST["p_allprice"]);

// ตรวจสอบการอัปโหลดรูปภาพ
$date1 = date("Ymd_His");
$numrand = (mt_rand());
$p_img = isset($_POST['p_img']) ? $_POST['p_img'] : '';
$upload = $_FILES['p_img']['name'];

// หากมีการอัปโหลดรูปภาพใหม่
if ($upload != '') {
    $path = "../p_img/";
    $type = strrchr($_FILES['p_img']['name'], ".");
    $newname = $numrand . $date1 . $type;
    $path_copy = $path . $newname;
    
    // ย้ายไฟล์ไปยังโฟลเดอร์
    if (move_uploaded_file($_FILES['p_img']['tmp_name'], $path_copy)) {
        $p_img = $newname;
    } else {
        echo "Error: ไม่สามารถอัปโหลดไฟล์ได้";
        exit();
    }
} else {
    $p_img = ''; // กำหนดค่าเป็นค่าว่าง หากไม่มีการอัปโหลดรูปภาพใหม่
}

// คำสั่ง SQL เพื่อเพิ่มข้อมูลสินค้าใหม่
$sql = "INSERT INTO tbl_product (p_name, type_id, topping_id, mix_id, p_detail, p_price, sugar_id, p_allprice, p_img)
        VALUES ('$p_name', '$type_id', '$topping_id', '$mix_id', '$p_detail', '$p_price', '$sugar_id', '$p_allprice', '$p_img')";

// รันคำสั่ง SQL
$result = mysqli_query($con, $sql);

// ตรวจสอบผลการเพิ่มข้อมูล
if ($result) {
    echo '<script>';
    echo "window.location='product.php?do=success';";
    echo '</script>';
} else {
    // แสดงข้อความ error หากการเพิ่มข้อมูลล้มเหลว
    echo '<script>';
    echo "alert('Error: " . mysqli_error($con) . "');";
    echo "window.location='product.php?act=add&do=f';";
    echo '</script>';
}

// ปิดการเชื่อมต่อฐานข้อมูล
mysqli_close($con);
?>
