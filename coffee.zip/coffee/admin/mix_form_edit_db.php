<?php
session_start();
include('../condb.php');

// ตรวจสอบสิทธิ์การเข้าถึง
if ($_SESSION['m_level'] != 'admin') {
    Header("Location: index.php");
    exit();
}

// รับค่าจากฟอร์ม
$mix_id = mysqli_real_escape_string($con, $_POST['mix_id']);
$m_mix = mysqli_real_escape_string($con, $_POST['m_mix']);
$m_price = mysqli_real_escape_string($con, $_POST['m_price']);

// อัปเดตข้อมูลใน `tbl_mix`
$sql = "UPDATE tbl_mix SET m_mix = '$m_mix', m_price = '$m_price' WHERE mix_id = $mix_id";
$result = mysqli_query($con, $sql) or die("Error in query: $sql " . mysqli_error($con));

// ตรวจสอบผลลัพธ์
if ($result) {
    echo "<script type='text/javascript'>";
    echo "alert('แก้ไขข้อมูลสำเร็จ!');";
    echo "window.location = 'mix.php';";
    echo "</script>";
} else {
    echo "<script type='text/javascript'>";
    echo "alert('เกิดข้อผิดพลาดในการแก้ไขข้อมูล');";
    echo "window.location = 'mix.php';";
    echo "</script>";
}

mysqli_close($con);
?>
