<?php
// เริ่มต้น session
session_start();

// เชื่อมต่อฐานข้อมูล
include('../condb.php');

// ตรวจสอบว่าผู้ใช้เข้าสู่ระบบแล้วหรือไม่
if (!isset($_SESSION['member_id'])) {
    header('Location: login.php');
    exit();
}

// ดึงข้อมูลผู้ใช้งานจากฐานข้อมูล
$member_id = $_SESSION['member_id']; // ID ของสมาชิกจาก session
$sql_user = "SELECT m_name, m_img FROM tbl_member WHERE member_id = '$member_id'";
$result_user = mysqli_query($con, $sql_user);
if ($row_user = mysqli_fetch_assoc($result_user)) {
    $m_name = $row_user['m_name'];  // ชื่อผู้ใช้งาน
    $m_img = $row_user['m_img'];    // รูปผู้ใช้งาน
} else {
    // กำหนดค่าเริ่มต้นถ้าไม่มีข้อมูล
    $m_name = "Guest";
    $m_img = "default.png";
}
?>

<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- Sidebar user panel (optional) -->
    <div class="user-panel">
      <div class="pull-left image">
        <img src="../m_img/<?php echo htmlspecialchars($m_img); ?>" class="img-circle" alt="User Image">
      </div>
      <div class="pull-left info">
        <p>คุณ <?php echo htmlspecialchars($m_name); ?></p>
        <!-- Status -->
        <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
      </div>
    </div>
    <ul class="sidebar-menu" data-widget="tree">
        <li>
            <a href="index.php"><i class="fa fa-home"></i>
                <span> หน้าหลัก</span>
            </a>
        </li>
        
        <li class="active">
            <a href="#"><i class="fa fa-cogs"></i> <span>จัดการข้อมูลระบบ</span>
            <span class="pull-right-container">
                <i class="fa fa-angle-down pull-right"></i>
            </span>
            </a>
        </li>
        
        <li>
            <a href="member.php"><i class="glyphicon glyphicon-record"></i>
                <span> จัดการสมาชิก</span>
            </a>
        </li>
        <li>
            <a href="type.php"><i class="glyphicon glyphicon-record"></i>
                <span> จัดการประเภท </span>
            </a>
        </li>
        <li>
            <a href="product.php"><i class="glyphicon glyphicon-record"></i>
                <span> จัดการสินค้า </span>
            </a>
        </li>
        <li>
            <a href="topping.php"><i class="glyphicon glyphicon-record"></i>
                <span> จัดการท็อปปิ้ง </span>
            </a>
        </li>
        <li>
            <a href="mix.php"><i class="glyphicon glyphicon-record"></i>
                <span> จัดการคุณสมบัติน้ำ </span>
            </a>
        </li>
        <li>
            <a href="sugar.php"><i class="glyphicon glyphicon-record"></i>
                <span> จัดการระดับความหวาน </span>
            </a>
        </li>
        <li>
            <a href="member_profile.php"><i class="glyphicon glyphicon-record"></i>
                <span> แก้ไขข้อมูลส่วนตัว </span>
            </a>
        </li>
        
        <li class="active">
            <a href="#"><i class="fa fa-cogs"></i> <span>จัดการข้อมูลรายงาน</span>
            <span class="pull-right-container">
                <i class="fa fa-angle-down pull-right"></i>
            </span>
            </a>
        </li>
        
        <li>
            <a href="order.php"><i class="glyphicon glyphicon-record"></i>
                <span> รายงานการสั่งซื้อ </span>
            </a>
        </li>

        <li>
            <a href="success_order.php"><i class="glyphicon glyphicon-record"></i>
                <span> รายงานการสั่งซื้อเสร็จสิ้น </span>
            </a>
        </li>
        
        <li>
            <a href="../logout.php" onclick="return confirm('คุณต้องการออกจากระบบหรือไม่ ?');"><i class="glyphicon glyphicon-off"></i>
                <span> ออกจากระบบ</span>
            </a>
        </li>
    </ul>
  </section>
  <!-- /.sidebar -->
</aside>
