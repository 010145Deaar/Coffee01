<?php
session_start();
echo '<meta charset="utf-8">';
include('../condb.php');

// ตรวจสอบว่าสิทธิ์ของผู้ใช้เป็น admin หรือไม่
if ($_SESSION['m_level'] != 'admin') {
    Header("Location: index.php");
    exit();
}

// รับค่าข้อมูลจากฟอร์ม
$m_mix = mysqli_real_escape_string($con, $_POST["m_mix"]);
$m_price = mysqli_real_escape_string($con, $_POST["m_price"]);

// ตรวจสอบว่าข้อมูลซ้ำหรือไม่
$check = "
    SELECT m_mix 
    FROM tbl_mix  
    WHERE m_mix = '$m_mix'
";
$result1 = mysqli_query($con, $check) or die(mysqli_error($con));
$num = mysqli_num_rows($result1);

if ($num > 0) {
    // หากข้อมูลซ้ำ ให้ redirect กลับไปที่หน้า mix.php พร้อมแจ้งเตือน
    echo '<script>';
    echo "alert('ชื่อรายการนี้มีอยู่แล้ว!');";
    echo "window.location='mix.php?act=add&do=d';";
    echo '</script>';
} else {
    // เพิ่มข้อมูลใหม่ใน tbl_mix
    $sql = "INSERT INTO tbl_mix (m_mix, m_price) VALUES ('$m_mix', '$m_price')";
    $result = mysqli_query($con, $sql) or die("Error in query: $sql " . mysqli_error($con));

    // ปิดการเชื่อมต่อฐานข้อมูล
    mysqli_close($con);

    // ตรวจสอบผลลัพธ์
    if ($result) {
        echo '<script>';
        echo "alert('เพิ่มข้อมูลสำเร็จ');";
        echo "window.location='mix.php?do=success';";
        echo '</script>';
    } else {
        echo '<script>';
        echo "alert('ไม่สามารถเพิ่มข้อมูลได้');";
        echo "window.location='mix.php?act=add&do=f';";
        echo '</script>';
    }
}
?>
