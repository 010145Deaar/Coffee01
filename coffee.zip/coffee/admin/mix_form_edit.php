<?php
// เริ่ม session และเชื่อมต่อฐานข้อมูล
session_start();
include('../condb.php');

// ตรวจสอบสิทธิ์การเข้าถึง
if ($_SESSION['m_level'] != 'admin') {
    Header("Location: index.php");
    exit();
}

// รับค่า ID จาก GET และป้องกัน SQL Injection
$ID = mysqli_real_escape_string($con, $_GET['ID']);

// ดึงข้อมูลของส่วนผสมจาก `tbl_mix`
$sql = "SELECT * FROM tbl_mix WHERE mix_id = $ID"; // เปลี่ยน `mix_id` ตามโครงสร้างจริงของตาราง
$result = mysqli_query($con, $sql) or die("Error in query: $sql " . mysqli_error($con));
$row = mysqli_fetch_array($result);
?>

<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>แก้ไขส่วนผสม</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>แก้ไขส่วนผสม</h1>
        <form action="mix_form_edit_db.php" method="post" class="form-horizontal">
            <!-- ฟิลด์สำหรับแก้ไขชื่อส่วนผสม -->
            <div class="form-group">
                <label for="m_mix" class="col-sm-2 control-label">ชื่อส่วนผสม:</label>
                <div class="col-sm-6">
                    <input 
                        type="text" 
                        name="m_mix" 
                        id="m_mix" 
                        required 
                        class="form-control" 
                        value="<?php echo htmlspecialchars($row['m_mix']); ?>"
                    >
                </div>
            </div>

            <!-- ฟิลด์สำหรับแก้ไขราคา -->
            <div class="form-group">
                <label for="m_price" class="col-sm-2 control-label">ราคา:</label>
                <div class="col-sm-6">
                    <input 
                        type="number" 
                        name="m_price" 
                        id="m_price" 
                        required 
                        class="form-control" 
                        value="<?php echo htmlspecialchars($row['m_price']); ?>"
                    >
                </div>
            </div>

            <!-- ปุ่มบันทึกและยกเลิก -->
            <div class="form-group">
                <div class="col-sm-6">
                    <input type="hidden" name="mix_id" value="<?php echo $ID; ?>"> <!-- ส่ง ID ไปยังไฟล์จัดการ -->
                    <button type="submit" class="btn btn-success">บันทึกการแก้ไข</button>
                    <a href="mix.php" class="btn btn-danger">ยกเลิก</a>
                </div>
            </div>
        </form>
    </div>
</body>
</html>
