<?php
session_start();
echo '<meta charset="utf-8">';
include('../condb.php');

// ตรวจสอบว่าเป็นผู้ดูแลระบบหรือไม่
if ($_SESSION['m_level'] != 'admin') {
    Header("Location: index.php");
    exit();
}

// รับค่าจากฟอร์มและตรวจสอบว่าเป็นตัวเลข
$s_name = mysqli_real_escape_string($con, $_POST["s_name"]);

if (!is_numeric($s_name)) {
    echo '<script>';
    echo "window.location='sugar.php?act=add&do=n';";  // หากค่าไม่เป็นตัวเลข, แสดงข้อความ
    echo '</script>';
    exit();
}

// ตรวจสอบว่ามีรายการในตารางที่มีชื่อเดียวกันหรือไม่
$check = "
SELECT s_name 
FROM tbl_sugar  
WHERE s_name = '$s_name'
";
$result1 = mysqli_query($con, $check) or die(mysqli_error($con));
$num = mysqli_num_rows($result1);

// ถ้ามีรายการที่ชื่อเดียวกันอยู่แล้ว
if ($num > 0) {
    echo '<script>';
    echo "window.location='sugar.php?act=add&do=d';";
    echo '</script>';
} else {
    // เพิ่มรายการใหม่
    $sql = "INSERT INTO tbl_sugar (s_name) VALUES ('$s_name')";
    $result = mysqli_query($con, $sql) or die("Error in query: $sql " . mysqli_error($con));
}

mysqli_close($con);

// ตรวจสอบผลลัพธ์และแสดงข้อความ
if ($result) {
    echo '<script>';
    echo "window.location='sugar.php?do=success';";
    echo '</script>';
} else {
    echo '<script>';
    echo "window.location='sugar.php?act=add&do=f';";
    echo '</script>';
}
?>
