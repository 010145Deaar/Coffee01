<?php 
session_start();
echo '<meta charset="utf-8">';
include('../condb.php');

// ตรวจสอบว่าสถานะเป็นผู้ดูแลหรือไม่
if ($_SESSION['m_level'] != 'admin') {
    Header("Location: index.php");
    exit();
}

// รับข้อมูลจากฟอร์ม
$m_level = mysqli_real_escape_string($con, $_POST["m_level"]);
$m_user = mysqli_real_escape_string($con, $_POST["m_user"]);
$m_pass = mysqli_real_escape_string($con, $_POST["m_pass"]);
$m_name = mysqli_real_escape_string($con, $_POST["m_name"]);
$m_tel = mysqli_real_escape_string($con, $_POST["m_tel"]);
$m_email = mysqli_real_escape_string($con, $_POST["m_email"]);
$m_address = mysqli_real_escape_string($con, $_POST["m_address"]);

// การอัปโหลดรูปภาพ
$date1 = date("Ymd_His");
$numrand = (mt_rand());
$upload = $_FILES['m_img']['name'];
if ($upload != '') { 
    $path = "../m_img/";
    $type = strrchr($_FILES['m_img']['name'], ".");
    $newname = $numrand . $date1 . $type;
    $path_copy = $path . $newname;

    // ย้ายไฟล์ไปยังโฟลเดอร์ที่กำหนด
    if (!move_uploaded_file($_FILES['m_img']['tmp_name'], $path_copy)) {
        echo '<script>';
        echo "alert('ไม่สามารถอัปโหลดรูปภาพได้');";
        echo "window.location='member.php?act=add&do=f';";
        echo '</script>';
        exit();
    }
} else {
    $newname = ''; // ถ้าไม่มีการอัปโหลดรูป ให้ตั้งค่าว่าง
}

// ตรวจสอบว่าชื่อผู้ใช้ซ้ำหรือไม่
$check = "SELECT m_user FROM tbl_member WHERE m_user = '$m_user'";
$result1 = mysqli_query($con, $check) or die(mysqli_error($con));
$num = mysqli_num_rows($result1);

if ($num > 0) {
    // ชื่อผู้ใช้ซ้ำ
    echo '<script>';
    echo "window.location='member.php?act=add&do=d';";
    echo '</script>';
} else {
    // เพิ่มข้อมูลใหม่
    $sql = "INSERT INTO tbl_member (m_level, m_user, m_pass, m_name, m_img, m_tel, m_email, m_address) 
            VALUES ('$m_level', '$m_user', '$m_pass', '$m_name', '$newname', '$m_tel', '$m_email', '$m_address')";

    $result = mysqli_query($con, $sql) or die("Error in query: $sql " . mysqli_error($con));
    mysqli_close($con);

    if ($result) {
        echo '<script>';
        echo "window.location='member.php?do=success';";
        echo '</script>';
    } else {
        echo '<script>';
        echo "window.location='member.php?act=add&do=f';";
        echo '</script>';
    }
}
?>
