<?php 

 if(@$_GET['do']=='success'){
    echo '<script type="text/javascript">
          swal("", "ทำรายการสำเร็จ !!", "success");
          </script>';
    echo '<meta http-equiv="refresh" content="1;url=topping.php" />';

  }else if(@$_GET['do']=='finish'){
    echo '<script type="text/javascript">
          swal("", "แก้ไขสำเร็จ !!", "success");
          </script>';
    echo '<meta http-equiv="refresh" content="1;url=topping.php" />';

  }else if(@$_GET['do']=='wrong'){
    echo '<script type="text/javascript">
          swal("", "รหัสผ่านใหม่ไม่ตรงกัน !!", "warning");
          </script>';
    echo '<meta http-equiv="refresh" content="1;url=topping.php" />';

  }else if(@$_GET['do']=='error'){
    echo '<script type="text/javascript">
          swal("", "ผิดพลาด !!", "error");
          </script>';
    echo '<meta http-equiv="refresh" content="1;url=topping.php" />';
  }

$query = "SELECT * FROM tbl_topping ORDER BY topping_id DESC" or die("Error:" . mysqli_error());
$result = mysqli_query($con, $query);
echo ' <table id="example1" class="table table-bordered table-striped">';
  echo "<thead>";
    echo "<tr class=''>
      <th width='5%'>ID</th>
      <th>ประเภทท็อปปิ้ง</th>
      <th width='5%'>ราคา</th>
      <th width='5%'></th>
    </tr>";
  echo "</thead>";
  while($row = mysqli_fetch_array($result)) {
  echo "<tr>";
    echo "<td>" .$row["topping_id"] .  "</td> ";
    echo "<td>" .$row["t_topping"] .  "</td> ";
    echo "<td>" .$row["t_price"] .  "</td> ";
    echo "<td><a href='topping.php?act=edit&ID=$row[topping_id]' class='btn btn-warning btn-xs'><span class='glyphicon glyphicon-edit'></span></a>         
    </td> ";
    echo "<td><a href='topping_del_db.php?ID=$row[topping_id]' onclick=\"return confirm('ยันยันการลบ')\" class='btn btn-danger btn-xs'><span class='glyphicon glyphicon-trash'></span></a></td> ";
  echo "</tr>";
  }
echo "</table>";
mysqli_close($con);
?>