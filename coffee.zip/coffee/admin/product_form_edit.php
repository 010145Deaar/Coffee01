<?php 
$ID = mysqli_real_escape_string($con,$_GET['ID']);
$sql = "SELECT * FROM tbl_product as p 
INNER JOIN tbl_type as t ON p.type_id = t.type_id
WHERE p_id=$ID
ORDER BY p.p_id DESC" or die("Error:" . mysqli_error());
$result = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error());
$row = mysqli_fetch_array($result);

$sql2 = "SELECT * FROM tbl_type 
ORDER BY type_id DESC" or die("Error:" . mysqli_error());
$result_t = mysqli_query($con, $sql2) or die ("Error in query: $sql " . mysqli_error());

?>
<script type="text/javascript">
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah').attr('src', e.target.result);
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }
</script>

<form action="product_form_edit_db.php" method="post" class="form-horizontal" enctype="multipart/form-data">
  <div class="form-group">
    <div class="col-sm-2 control-label">
      ชื่อสินค้า :
    </div>
    <div class="col-sm-3">
      <input type="text" name="p_name" required class="form-control" value="<?php echo $row['p_name'];?>">
    </div>
  </div>

   <div class="form-group">
    <div class="col-sm-2 control-label">
      ประเภทสินค้า :
    </div>
    <div class="col-sm-3">
        <select name="type_id" class="form-control" required>
              <option value="<?php echo $row['type_id'];?>"><?php echo $row['type_name'];?></option>
              <option value="">เลือกประเภทสินค้า</option>
              <?php foreach($result_t as $results){?>
              <option value="<?php echo $results["type_id"];?>">
                <?php echo $results["type_name"]; ?>
              </option>
              <?php } ?>
        </select>
    </div>
  </div>

  <div class="form-group">
    <div class="col-sm-2 control-label">
      รายละเอียด :
    </div>
    <div class="col-sm-3">
    <textarea name="p_detail" cols="60"><?php echo $row['p_detail'];?></textarea>
    </div>
  </div>

  <div class="form-group">
    <div class="col-sm-2 control-label">
      ราคา :
    </div>
    <div class="col-sm-2">
      <input type="number" name="p_price" id="p_price" required class="form-control" value="<?php echo $row['p_price'];?>">
    </div>
</div> 

<div class="form-group">
    <div class="col-sm-2 control-label">
        ระดับความหวาน :
    </div>
    <div class="col-sm-3">
        <select name="sugar_id" id="sugar_id" required>
            <option value="">เลือกระดับความหวาน</option>
            <?php
            // ดึงข้อมูลระดับความหวานจากฐานข้อมูล
            $sql = "SELECT sugar_id, s_name FROM tbl_sugar ORDER BY sugar_id ASC";
            $result_sugar = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error($con));
            while ($sugar = mysqli_fetch_assoc($result_sugar)) {
                // แสดงระดับความหวานโดยไม่รวมราคา
                echo '<option value="' . $sugar['sugar_id'] . '">' . $sugar['s_name'] . '</option>';
            }
            ?>
        </select>
    </div>
</div>

<div class="form-group">
    <div class="col-sm-2 control-label">
        เลือกท็อปปิ้ง :
    </div>
    <div class="col-sm-3">
        <select name="topping_id" id="topping_id" class="form-control" required onchange="calculateTotalPrice()">
            <option value="">เลือกท็อปปิ้ง</option>
            <?php
            $sql = "SELECT topping_id, t_topping, t_price FROM tbl_topping ORDER BY topping_id ASC";
            $result_topping = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error($con));
            while ($topping = mysqli_fetch_assoc($result_topping)) {
                echo '<option value="' . $topping['topping_id'] . '" data-price="' . $topping['t_price'] . '">'
                     . $topping['t_topping'] . ' (+' . $topping['t_price'] . ' บาท)</option>';
            }
            ?>
        </select>
    </div>
</div>

<div class="form-group">
    <div class="col-sm-2 control-label">
        เลือกการปั่น :
    </div>
    <div class="col-sm-3">
        <select name="mix_id" id="mix_id" class="form-control" required onchange="calculateTotalPrice()">
            <option value="">เลือกการปั่น</option>
            <?php
            $sql = "SELECT mix_id, m_mix, m_price FROM tbl_mix ORDER BY mix_id ASC";
            $result_mix = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error($con));
            while ($mix = mysqli_fetch_assoc($result_mix)) {
                echo '<option value="' . $mix['mix_id'] . '" data-price="' . $mix['m_price'] . '">'
                     . $mix['m_mix'] . ' (+' . $mix['m_price'] . ' บาท)</option>';
            }
            ?>
        </select>
    </div>
</div>

<div class="form-group">
    <div class="col-sm-2 control-label">
        ราคารวม :
    </div>
    <div class="col-sm-2">
        <input type="number" name="p_allprice" id="p_allprice" class="form-control" readonly>
    </div>
</div>

<script>
  function calculateTotalPrice() {
    // ดึงราคาพื้นฐาน (p_price)
    const basePrice = parseFloat(document.getElementById('p_price').value) || 0;

    // ดึงราคาจากท็อปปิ้ง (topping_id)
    const toppingSelect = document.getElementById('topping_id');
    const selectedTopping = toppingSelect.options[toppingSelect.selectedIndex];
    const toppingPrice = parseFloat(selectedTopping.getAttribute('data-price')) || 0;

    // ดึงราคาจากการปั่น (mix_id)
    const mixSelect = document.getElementById('mix_id');
    const selectedMix = mixSelect.options[mixSelect.selectedIndex];
    const mixPrice = parseFloat(selectedMix.getAttribute('data-price')) || 0;

    // คำนวณราคารวม
    const totalPrice = basePrice + toppingPrice + mixPrice;

    // แสดงราคารวมในช่อง p_allprice
    document.getElementById('p_allprice').value = totalPrice.toFixed(2);
}

// ฟังก์ชันนี้จะถูกเรียกเมื่อมีการเปลี่ยนแปลงค่าของราคา, ท็อปปิ้ง, หรือการปั่น
document.getElementById('p_price').addEventListener('input', calculateTotalPrice);
</script>

<div class="form-group">
    <div class="col-sm-2 control-label">
      รูปภาพสินค้า :
    </div>
    <div class="col-sm-4">
      ภาพเก่า <br>
      <img src="../p_img/<?php echo $row['p_img'];?>" width="200px">
      <br>
      <input type="file" name="p_img" class="form-control" accept="image/*" onchange="readURL(this);"/>
      <img id="blah" src="#" alt="" width="250" class="img-rounded" style="margin-top: 10px;">
    </div>
</div>

  <div class="form-group">
    <div class="col-sm-2">
    </div>
    <div class="col-sm-3">
       <input type="hidden" name="p_img2" value="<?php echo $row['p_img'];?>">
      <input type="hidden" name="p_id" value="<?php echo $ID; ?>" />
      <button type="submit" class="btn btn-success">แก้ไขข้อมูล</button>
      <a href="product.php" class="btn btn-danger">ยกเลิก</a>
    </div>
  </div>
</form> 