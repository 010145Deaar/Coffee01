<?php 
// การแสดงผลคำเตือนสำหรับสถานะสำเร็จ
if (@$_GET['do'] == 'success') {
    echo '<script type="text/javascript">
          swal("", "ทำรายการสำเร็จ !!", "success");
          </script>';
    echo '<meta http-equiv="refresh" content="1;url=product.php" />';
} else if (@$_GET['do'] == 'finish') {
    echo '<script type="text/javascript">
          swal("", "แก้ไขสำเร็จ !!", "success");
          </script>';
    echo '<meta http-equiv="refresh" content="1;url=product.php" />';
}

// ดึงข้อมูลสินค้าจากฐานข้อมูล
$query = "SELECT p.*, t.t_topping AS t_topping, t.t_price, m.m_mix AS m_mix, m.m_price
          FROM tbl_product AS p
          INNER JOIN tbl_type AS t_type ON p.type_id = t_type.type_id
          LEFT JOIN tbl_topping AS t ON p.topping_id = t.topping_id
          LEFT JOIN tbl_mix AS m ON p.mix_id = m.mix_id
          ORDER BY p.p_id DESC";
$result = mysqli_query($con, $query);

// แสดงผลตารางข้อมูล
echo '<table id="example1" class="table table-bordered table-striped">';
echo "<thead>";
echo "<tr>
        <th width='3%' class='hidden-xs'>ID</th>
        <th width='8%' class='hidden-xs'>รูป</th>
        <th width='20%'>ชื่อสินค้า</th>
        <th width='30%' class='hidden-xs'>รายละเอียดสินค้า</th>
        <th>ราคาสินค้า</th>
        <th>ราคารวมน้ำ</th>
        <th width='7%'>-</th>
      </tr>";
echo "</thead>";

while ($row = mysqli_fetch_array($result)) {
    // คำนวณราคารวม (p_allprice) จากข้อมูลต่างๆ
    $toppingPrice = isset($row['t_price']) ? $row['t_price'] : 0;
    $mixPrice = isset($row['m_price']) ? $row['m_price'] : 0;
    $totalPrice = $row['p_price'] + $toppingPrice + $mixPrice;

    echo "<tr>";
    echo "<td class='hidden-xs'>" . $row["p_id"] . "</td>";
    echo "<td class='hidden-xs'><img src='../p_img/" . $row['p_img'] . "' width='100%'></td>";
    echo "<td>
            ชื่อ: " . $row["p_name"] . "<br>
            ประเภท: <font color='blue'>" . $row["type_id"] . "</font>
          </td>";
    echo "<td class='hidden-xs'>" . $row["p_detail"] . "</td>";
    echo "<td>
            ราคาน้ำ " . $row["p_price"] . " บาท<br>
            ราคาท็อปปิ้ง " . $toppingPrice . " บาท<br>
            รายการท็อปปิ้ง " . $row["t_topping"] . "<br>
            ราคาตัวเลือกการปั่น " . $mixPrice . " บาท<br>
            ตัวเลือกการปั่น " . $row["m_mix"] . "<br>
            ระดับความหวาน " . $row["sugar_id"] . "%<br>
          </td>";
    echo "<td> ราคารวม " . $totalPrice . " บาท</td>";
    echo "<td>
            <a href='product.php?act=edit&ID=" . $row['p_id'] . "' class='btn btn-warning btn-xs'>
              <span class='glyphicon glyphicon-edit'></span>
            </a> 
            <a href='product_del_db.php?ID=" . $row['p_id'] . "' onclick=\"return confirm('ยืนยันการลบ')\" class='btn btn-danger btn-xs'>
              <span class='glyphicon glyphicon-trash'></span>
            </a>
          </td>";
    echo "</tr>";
}
echo "</table>";

// ปิดการเชื่อมต่อฐานข้อมูล
mysqli_close($con);
?>
