<?php
include('h.php');
include("condb.php");
?>
<!DOCTYPE html>
<html>
<head>
  <?php include('boot4.php'); ?>
</head>
<body>
  <?php
    include('banner.php');
    include('navbar.php');
  ?>
  
  <div class="container">
    <div class="row">
      <div class="col-md-12" style="margin-top: 10px">
        <div class="row">
          <?php
          // ตรวจสอบและกำหนดค่าเริ่มต้นให้กับตัวแปร
          $act = isset($_GET['act']) ? $_GET['act'] : '';
          $q = isset($_GET['q']) ? $_GET['q'] : '';

          if ($act == 'showbytype') {
            include('list_prd_by_type.php');
          } else if (!empty($q)) {
            include("show_product_q.php");
          } else if ($act == 'add') {
            include("member_form_add.php");
          } else {
            include('show_product.php');
          }
          ?>
        </div>
      </div>
    </div>
  </div>
  <a style="color:red" href="https://www.w3schools.com/html/tryit.asp?filename=tryhtml_basic_link">FF</a>
  <h4>ผู้จัดทำ</h4>
  <p>นายจีรวัฒน์ เดชแฟง นายจีรวัฒน์ เดชแฟง นายจีรวัฒน์ เดชแฟง </p>
</body>
</html>
<?php include('script4.php'); ?>
