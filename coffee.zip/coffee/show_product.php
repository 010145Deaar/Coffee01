<?php   
$q = isset($_GET['q']) ? $_GET['q'] : ''; // ตรวจสอบว่ามีค่า q หรือไม่
$type_id = isset($_GET['type_id']) ? $_GET['type_id'] : ''; // รับค่าประเภทสินค้าที่เลือก
$page = isset($_GET['page']) ? intval($_GET['page']) : 1; // หน้าเริ่มต้น
$limit = 10; // จำนวนสินค้าต่อหน้า
$offset = ($page - 1) * $limit; // คำนวณตำแหน่งเริ่มต้น

include("condb.php");

// สร้างคำสั่ง SQL หลัก
$sql_base = "SELECT p.p_id, p.p_name, p.p_img, p.p_price, t.type_id, t.type_name 
             FROM tbl_product AS p
             INNER JOIN tbl_type AS t ON p.type_id = t.type_id";

// เงื่อนไขการกรองสินค้า
$where_conditions = [];
if (!empty($type_id)) {
    $where_conditions[] = "p.type_id = '$type_id'";
}
if (!empty($q)) {
    $where_conditions[] = "p.p_name LIKE '%$q%'";
}

// รวมเงื่อนไขทั้งหมดในคำสั่ง SQL
if (count($where_conditions) > 0) {
    $sql_base .= " WHERE " . implode(' AND ', $where_conditions);
}

// นับจำนวนสินค้าทั้งหมดเพื่อตรวจสอบจำนวนหน้า
$sql_count = $sql_base; // คำสั่งนับจำนวน
$sql_count = str_replace("SELECT p.p_id, p.p_name, p.p_img, p.p_price, t.type_id, t.type_name", "SELECT COUNT(*) AS total", $sql_count);
$result_count = mysqli_query($con, $sql_count);
$total_items = mysqli_fetch_assoc($result_count)['total'];
$total_pages = ceil($total_items / $limit);

// เพิ่มการจัดเรียงและแบ่งหน้าในคำสั่ง SQL หลัก
$sql = $sql_base . " ORDER BY p.p_id DESC LIMIT $limit OFFSET $offset";
$result = mysqli_query($con, $sql) or die("Error in query: $sql " . mysqli_error($con));
?>

<div class="container">
    <h2>สินค้าทั้งหมด</h2> <!-- หรือชื่อหมวดหมู่ที่เลือก -->
    <div class="row">
        <?php 
        if (mysqli_num_rows($result) > 0) {
            while ($row_prd = mysqli_fetch_array($result)) { ?>
                <div class="col-lg-3 col-md-4 col-sm-6 col-12 mb-4 d-flex justify-content-center">
                    <div class="card border-light" style="width: 100%; max-width: 300px;">
                        <a href="prd.php?id=<?php echo $row_prd['p_id']; ?>" class="text-center">
                            <img src="p_img/<?php echo $row_prd['p_img']; ?>" class="card-img-top img-fluid" alt="<?php echo $row_prd['p_name']; ?>" style="height: auto; max-height: 200px; object-fit: cover;">
                        </a>
                        <div class="card-body text-center">
                            <a href="prd.php?id=<?php echo $row_prd['p_id']; ?>"><b><?php echo $row_prd["p_name"]; ?></b></a>
                            <p class="mb-2">ราคา <span class="text-danger"><?php echo $row_prd["p_price"]; ?></span> บาท</p>
                            <a href="prd.php?id=<?php echo $row_prd['p_id']; ?>" class="btn btn-info btn-sm text-white">รายละเอียด</a>
                        </div>
                    </div>
                </div>
            <?php } 
        } else {
            echo '<div class="col-12 text-center"><p>ไม่พบสินค้า</p></div>';
        }
        ?>
    </div>

    <!-- ส่วนของการแบ่งหน้า -->
    <nav>
        <ul class="pagination justify-content-center">
            <?php if ($page > 1) { ?>
            <li class="page-item">
                <a class="page-link" href="?<?php echo http_build_query(['q' => $q, 'type_id' => $type_id, 'page' => $page - 1]); ?>">ก่อนหน้า</a>
            </li>
            <?php } ?>

            <?php for ($i = 1; $i <= $total_pages; $i++) { ?>
            <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                <a class="page-link" href="?<?php echo http_build_query(['q' => $q, 'type_id' => $type_id, 'page' => $i]); ?>"><?php echo $i; ?></a>
            </li>
            <?php } ?>

            <?php if ($page < $total_pages) { ?>
            <li class="page-item">
                <a class="page-link" href="?<?php echo http_build_query(['q' => $q, 'type_id' => $type_id, 'page' => $page + 1]); ?>">ถัดไป</a>
            </li>
            <?php } ?>
        </ul>
    </nav>
</div>

<?php 
// ปิดการเชื่อมต่อฐานข้อมูล
mysqli_close($con);
?>
