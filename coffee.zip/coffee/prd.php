<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>รายละเอียดสินค้า</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="mystyle.css">
</head>
<body>
<?php
include('banner.php');
include('navbar.php');
$p_id = $_GET["id"];
$sql = "SELECT * FROM tbl_product AS p 
        INNER JOIN tbl_type AS t ON p.type_id = t.type_id 
        WHERE p_id = $p_id";
$result = mysqli_query($con, $sql) or die("Error in query: $sql " . mysqli_error());
$row = mysqli_fetch_array($result);
?>

<div class="container mt-5">
    <div class="row">
        <!-- แสดงภาพสินค้า -->
        <div class="col-lg-6 col-md-6 col-sm-12 text-center">
            <img src="p_img/<?php echo $row['p_img']; ?>" class="img-fluid rounded" alt="Product Image">
        </div>
        <!-- แสดงรายละเอียดสินค้า -->
        <div class="col-lg-6 col-md-6 col-sm-12">
            <h3><?php echo $row["p_name"]; ?></h3>
            <p><?php echo $row["p_detail"]; ?></p>
            <p>ประเภท: <strong><?php echo $row["type_name"]; ?></strong></p>
            <p>ราคา: <span class="text-danger font-weight-bold"><?php echo $row["p_price"]; ?> บาท</span></p>

                    <div class="form-group">
            <div class="col-sm-2 control-label">
                ระดับความหวาน :
            </div>
            <div class="col-sm-3">
                <select name="sugar_id" id="sugar_id" required>
                    <option value="">เลือกระดับความหวาน</option>
                    <?php
                    // ดึงข้อมูลระดับความหวานจากฐานข้อมูล
                    $sql = "SELECT sugar_id, s_name FROM tbl_sugar ORDER BY sugar_id ASC";
                    $result_sugar = mysqli_query($con, $sql) or die ("Error in query: $sql " . mysqli_error($con));
                    while ($sugar = mysqli_fetch_assoc($result_sugar)) {
                        // แสดงระดับความหวานโดยไม่รวมราคา
                        echo '<option value="' . $sugar['sugar_id'] . '">' . $sugar['s_name'] . '</option>';
                    }
                    ?>
                </select>
            </div>
        </div>

            <!-- เลือกท็อปปิ้ง -->
            <div class="form-group">
                <label for="topping_id">เลือกท็อปปิ้ง:</label>
                <select name="topping_id" id="topping_id" class="form-control" onchange="calculateTotalPrice()">
                    <option value="">เลือกท็อปปิ้ง</option>
                    <?php
                    $sql = "SELECT topping_id, t_topping, t_price FROM tbl_topping ORDER BY topping_id ASC";
                    $result_topping = mysqli_query($con, $sql);
                    while ($topping = mysqli_fetch_assoc($result_topping)) {
                        echo '<option value="' . $topping['topping_id'] . '" data-price="' . $topping['t_price'] . '">'
                             . $topping['t_topping'] . ' (+' . $topping['t_price'] . ' บาท)</option>';
                    }
                    ?>
                </select>
            </div>

            <!-- เลือกการปั่น -->
            <div class="form-group">
                <label for="mix_id">เลือกการปั่น:</label>
                <select name="mix_id" id="mix_id" class="form-control" onchange="calculateTotalPrice()" required>
                    <option value="">เลือกการปั่น</option>
                    <?php
                    $sql = "SELECT mix_id, m_mix, m_price FROM tbl_mix ORDER BY mix_id ASC";
                    $result_mix = mysqli_query($con, $sql);

                    while ($mix = mysqli_fetch_assoc($result_mix)) {
                        // เงื่อนไข: หาก type_id = 4 ให้แสดงเฉพาะ mix_id = 13
                        if ($row['type_id'] == 4 && $mix['mix_id'] != 13) {
                            continue; // ข้ามตัวเลือกอื่นๆ
                        }

                        // เงื่อนไข: หาก type_id != 4 ให้ข้าม mix_id = 13
                        if ($row['type_id'] != 4 && $mix['mix_id'] == 13) {
                            continue; // ข้าม mix_id = 13
                        }

                        // เพิ่มตัวเลือกใน Dropdown
                        echo '<option value="' . $mix['mix_id'] . '" data-price="' . $mix['m_price'] . '">'
                            . $mix['m_mix'] . ' (+' . $mix['m_price'] . ' บาท)</option>';
                    }
                    ?>
                </select>
            </div>

            <!-- ราคารวม -->
            <div class="form-group">
                <label for="p_allprice">ราคารวม:</label>
                <input type="number" name="p_allprice" id="p_allprice" class="form-control" readonly>
            </div>

        </div>
    </div>
</div>

<script>
    function calculateTotalPrice() {
        const basePrice = parseFloat('<?php echo $row["p_price"]; ?>') || 0;
        const toppingSelect = document.getElementById('topping_id');
        const toppingPrice = parseFloat(toppingSelect.options[toppingSelect.selectedIndex]?.dataset.price || 0);
        const mixSelect = document.getElementById('mix_id');
        const mixPrice = parseFloat(mixSelect.options[mixSelect.selectedIndex]?.dataset.price || 0);
        document.getElementById('p_allprice').value = (basePrice + toppingPrice + mixPrice).toFixed(2);
    }
</script>

<!-- Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
