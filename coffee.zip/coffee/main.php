<a href="https://colorlib.com/wp/templates/"><img src="https://colorlib.com/wp/wp-content/uploads/sites/2/colorlib-push-logo.png" alt="Colorlib logo"></a>
<h1 style="text-align:center;">Thank you for using our template!</h1>
<p style="text-align:center;">For more awesome templates please visit <strong><a href="https://colorlib.com/wp/templates/">Colorlib</a></strong>.</p>

<style>
img {
  margin: 0 auto;
  display: block;
  margin-top: 20%;
}
</style>
