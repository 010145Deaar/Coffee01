<?php
// เชื่อมต่อฐานข้อมูล
include('condb.php'); // แก้เป็นไฟล์การเชื่อมต่อของคุณ

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $m_user = mysqli_real_escape_string($con, $_POST['m_user']);
    $m_email = mysqli_real_escape_string($con, $_POST['m_email']);
    $m_pass = mysqli_real_escape_string($con, $_POST['m_pass']); // ใช้รหัสผ่านที่รับเข้ามาโดยตรง

    // ตรวจสอบว่ามี username และ email ตรงกันหรือไม่
    $sql = "SELECT * FROM tbl_member WHERE m_user = '$m_user' AND m_email = '$m_email'";
    $result = mysqli_query($con, $sql);

    if (mysqli_num_rows($result) > 0) {
        // ถ้าพบข้อมูล ให้ทำการอัปเดตรหัสผ่าน
        $update_sql = "UPDATE tbl_member SET m_pass = '$m_pass' WHERE m_user = '$m_user' AND m_email = '$m_email'";

        if (mysqli_query($con, $update_sql)) {
            echo "<script>
                alert('เปลี่ยนรหัสผ่านสำเร็จ');
                window.location.href = 'form_login.php'; // เปลี่ยนเส้นทางไปหน้าล็อกอิน
            </script>";
        } else {
            echo "<script>
                alert('เกิดข้อผิดพลาดในการเปลี่ยนรหัสผ่าน');
                window.history.back();
            </script>";
        }
    } else {
        // ถ้าไม่พบข้อมูล
        echo "<script>
            alert('ตรวจสอบไม่พบข้อมูลในระบบ');
            window.history.back();
        </script>";
    }
}

// ปิดการเชื่อมต่อฐานข้อมูล
mysqli_close($con);
?>
