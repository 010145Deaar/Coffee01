<?php include('condb.php'); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Coffee</title>
    
    <!-- เปลี่ยน favicon ที่นี่ -->
    <link rel="icon" href="coffee.png" type="type="image/png"">
    
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>
  <body>
    <!-- เนื้อหาของคุณที่นี่ -->
  </body>
</html>
