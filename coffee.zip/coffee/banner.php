<div class="col-md-12 text-center" style="width: 100%; display: flex; justify-content: center;">
    <img src="banner/S__5218311.jpg" alt="Banner" style="width: 100%; max-width: 1200px; height: auto;">
</div>